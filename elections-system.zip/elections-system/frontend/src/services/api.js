import axios from 'axios';

const API_URL = process.env.REACT_APP_API_URL || 'http://localhost:3001/api';

const api = axios.create({
  baseURL: API_URL,
  headers: {
    'Content-Type': 'application/json',
  },
});

// Add auth token to requests
api.interceptors.request.use((config) => {
  const token = localStorage.getItem('token');
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});

// Handle auth errors
api.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response?.status === 401 || error.response?.status === 403) {
      localStorage.removeItem('token');
      localStorage.removeItem('user');
      window.location.href = '/login';
    }
    return Promise.reject(error);
  }
);

// Auth
export const login = (username, password) => 
  api.post('/auth/login', { username, password });

export const getCurrentUser = () => 
  api.get('/auth/me');

// Dashboard
export const getDashboard = () => 
  api.get('/dashboard');

// Campaigns
export const getCampaigns = () => 
  api.get('/campaigns');

export const getCampaign = (id) => 
  api.get(`/campaigns/${id}`);

export const createCampaign = (data) => 
  api.post('/campaigns', data);

export const updateCampaign = (id, data) => 
  api.put(`/campaigns/${id}`, data);

export const deleteCampaign = (id) => 
  api.delete(`/campaigns/${id}`);

export const getCampaignMembers = (campaignId) => 
  api.get(`/campaigns/${campaignId}/members`);

export const addMembersToCampaign = (campaignId, memberIds) => 
  api.post(`/campaigns/${campaignId}/members`, { member_ids: memberIds });

export const removeMemberFromCampaign = (campaignId, memberId) => 
  api.delete(`/campaigns/${campaignId}/members/${memberId}`);

export const addAllMembersToCampaign = (campaignId) => 
  api.post(`/campaigns/${campaignId}/members/all`);

// Members
export const getMembers = (params) => 
  api.get('/members', { params });

export const getMember = (id) => 
  api.get(`/members/${id}`);

export const createMember = (data) => 
  api.post('/members', data);

export const updateMember = (id, data) => 
  api.put(`/members/${id}`, data);

export const deleteMember = (id) => 
  api.delete(`/members/${id}`);

export const importMembers = (formData) => 
  api.post('/members/import', formData, {
    headers: { 'Content-Type': 'multipart/form-data' }
  });

export const exportMembers = () => 
  api.get('/members/export/csv', { responseType: 'blob' });

export const getMemberStats = () => 
  api.get('/members/stats/overview');

// Broadcasts
export const getBroadcasts = (params) => 
  api.get('/broadcasts', { params });

export const getBroadcast = (id) => 
  api.get(`/broadcasts/${id}`);

export const createBroadcast = (data) => 
  api.post('/broadcasts', data);

export const createMediaBroadcast = (formData) => 
  api.post('/broadcasts/media', formData, {
    headers: { 'Content-Type': 'multipart/form-data' }
  });

export const updateBroadcast = (id, data) => 
  api.put(`/broadcasts/${id}`, data);

export const deleteBroadcast = (id) => 
  api.delete(`/broadcasts/${id}`);

export const addBroadcastRecipients = (broadcastId, data) => 
  api.post(`/broadcasts/${broadcastId}/recipients`, data);

export const sendBroadcast = (id) => 
  api.post(`/broadcasts/${id}/send`);

export const getBroadcastStats = () => 
  api.get('/broadcasts/stats/overview');

// WhatsApp
export const getWhatsAppStatus = () => 
  api.get('/whatsapp/status');

export const sendTestMessage = (phone, message) => 
  api.post('/whatsapp/test', { phone, message });

export const sendMessageToMember = (memberId, data) => 
  api.post(`/whatsapp/send/${memberId}`, data);

export const getMessageHistory = (memberId) => 
  api.get(`/whatsapp/history/${memberId}`);

export default api;
xport const getVotingPage = (token) => 
  axios.get(`${API_URL}/vote/${token}`);

export const submitVote = (token, selections) => 
  axios.post(`${API_URL}/vote/${token}`, { selections });

export default api;
st getWhatsAppStatus = () => 
  api.get('/whatsapp/status');

export const sendTestMessage = (phone, message) => 
  api.post('/whatsapp/test', { phone, message });

export const sendMessageToMember = (memberId, data) => 
  api.post(`/whatsapp/send/${memberId}`, data);

export const getMessageHistory = (memberId) => 
  api.get(`/whatsapp/history/${memberId}`);

// Voting (public)
export const getVotingPage = (token) => 
  axios.get(`${API_URL}/vote/${token}`);

export const submitVote = (token, selections) => 
  axios.post(`${API_URL}/vote/${token}`, { selections });

export default api;
