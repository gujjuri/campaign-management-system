import React, { useState, useEffect } from 'react';
import { getWhatsAppStatus, sendTestMessage } from '../services/api';
import {
  Settings as SettingsIcon,
  MessageSquare,
  CheckCircle,
  XCircle,
  Send,
  RefreshCw
} from 'lucide-react';

const Settings = () => {
  const [whatsappStatus, setWhatsappStatus] = useState(null);
  const [checkingStatus, setCheckingStatus] = useState(false);
  const [testPhone, setTestPhone] = useState('');
  const [testMessage, setTestMessage] = useState('Hello! This is a test message from Elections Campaign Manager.');
  const [sendingTest, setSendingTest] = useState(false);
  const [testResult, setTestResult] = useState(null);

  const [settings, setSettings] = useState({
    api_url: 'http://localhost:8080',
    api_key: '',
    instance: ''
  });

  useEffect(() => {
    checkWhatsAppStatus();
  }, []);

  const checkWhatsAppStatus = async () => {
    setCheckingStatus(true);
    try {
      const response = await getWhatsAppStatus();
      setWhatsappStatus(response.data);
    } catch (error) {
      setWhatsappStatus({ connected: false, error: error.message });
    } finally {
      setCheckingStatus(false);
    }
  };

  const handleSendTest = async () => {
    if (!testPhone || !testMessage) {
      alert('Please enter phone number and message');
      return;
    }

    setSendingTest(true);
    setTestResult(null);
    try {
      const response = await sendTestMessage(testPhone, testMessage);
      setTestResult(response.data);
    } catch (error) {
      setTestResult({ success: false, error: error.response?.data?.error || error.message });
    } finally {
      setSendingTest(false);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold text-gray-900">Settings</h1>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* WhatsApp Connection Status */}
        <div className="bg-white rounded-xl shadow-sm p-6">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-lg font-semibold text-gray-900 flex items-center">
              <MessageSquare className="h-5 w-5 mr-2 text-green-600" />
              WhatsApp Connection
            </h2>
            <button
              onClick={checkWhatsAppStatus}
              disabled={checkingStatus}
              className="p-2 hover:bg-gray-100 rounded-lg"
            >
              <RefreshCw className={`h-5 w-5 ${checkingStatus ? 'animate-spin' : ''}`} />
            </button>
          </div>

          <div className={`p-4 rounded-lg ${
            whatsappStatus?.state === 'open' || whatsappStatus?.connected
              ? 'bg-green-50 border border-green-200'
              : 'bg-red-50 border border-red-200'
          }`}>
            <div className="flex items-center">
              {whatsappStatus?.state === 'open' || whatsappStatus?.connected ? (
                <>
                  <CheckCircle className="h-6 w-6 text-green-600 mr-2" />
                  <div>
                    <p className="font-medium text-green-800">Connected</p>
                    <p className="text-sm text-green-600">
                      Evolution API is connected and ready to send messages
                    </p>
                  </div>
                </>
              ) : (
                <>
                  <XCircle className="h-6 w-6 text-red-600 mr-2" />
                  <div>
                    <p className="font-medium text-red-800">Not Connected</p>
                    <p className="text-sm text-red-600">
                      {whatsappStatus?.error || 'Please check your Evolution API configuration'}
                    </p>
                  </div>
                </>
              )}
            </div>
          </div>

          {whatsappStatus && (
            <div className="mt-4 text-sm text-gray-500">
              <p>State: {whatsappStatus.state || 'Unknown'}</p>
              {whatsappStatus.instance && <p>Instance: {whatsappStatus.instance}</p>}
            </div>
          )}
        </div>

        {/* Test Message */}
        <div className="bg-white rounded-xl shadow-sm p-6">
          <h2 className="text-lg font-semibold text-gray-900 mb-4 flex items-center">
            <Send className="h-5 w-5 mr-2 text-blue-600" />
            Send Test Message
          </h2>

          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Phone Number
              </label>
              <input
                type="tel"
                value={testPhone}
                onChange={(e) => setTestPhone(e.target.value)}
                placeholder="e.g., 1234567890"
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500"
              />
              <p className="text-xs text-gray-500 mt-1">
                Enter number with country code (without + sign)
              </p>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Message
              </label>
              <textarea
                value={testMessage}
                onChange={(e) => setTestMessage(e.target.value)}
                rows={3}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500"
              />
            </div>

            <button
              onClick={handleSendTest}
              disabled={sendingTest}
              className="w-full py-2 bg-primary-600 text-white rounded-lg hover:bg-primary-700 disabled:opacity-50"
            >
              {sendingTest ? 'Sending...' : 'Send Test Message'}
            </button>

            {testResult && (
              <div className={`p-4 rounded-lg ${
                testResult.success ? 'bg-green-50 text-green-800' : 'bg-red-50 text-red-800'
              }`}>
                {testResult.success ? (
                  <p>Message sent successfully!</p>
                ) : (
                  <p>Failed: {testResult.error}</p>
                )}
              </div>
            )}
          </div>
        </div>

        {/* Evolution API Configuration */}
        <div className="bg-white rounded-xl shadow-sm p-6 lg:col-span-2">
          <h2 className="text-lg font-semibold text-gray-900 mb-4 flex items-center">
            <SettingsIcon className="h-5 w-5 mr-2 text-gray-600" />
            Evolution API Configuration
          </h2>

          <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4 mb-4">
            <p className="text-sm text-yellow-800">
              <strong>Note:</strong> These settings are configured via environment variables in the backend.
              Update the <code className="bg-yellow-100 px-1 rounded">.env</code> file and restart the server to apply changes.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                API URL
              </label>
              <input
                type="text"
                value={settings.api_url}
                onChange={(e) => setSettings({ ...settings, api_url: e.target.value })}
                placeholder="http://localhost:8080"
                className="w-full px-4 py-2 border border-gray-300 rounded-lg bg-gray-50"
                disabled
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                API Key
              </label>
              <input
                type="password"
                value={settings.api_key}
                onChange={(e) => setSettings({ ...settings, api_key: e.target.value })}
                placeholder="Your API key"
                className="w-full px-4 py-2 border border-gray-300 rounded-lg bg-gray-50"
                disabled
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Instance Name
              </label>
              <input
                type="text"
                value={settings.instance}
                onChange={(e) => setSettings({ ...settings, instance: e.target.value })}
                placeholder="Your instance name"
                className="w-full px-4 py-2 border border-gray-300 rounded-lg bg-gray-50"
                disabled
              />
            </div>
          </div>

          <div className="mt-4 p-4 bg-gray-50 rounded-lg">
            <h3 className="font-medium text-gray-900 mb-2">Environment Variables</h3>
            <pre className="text-sm text-gray-600 overflow-x-auto">
{`EVOLUTION_API_URL=http://localhost:8080
EVOLUTION_API_KEY=your-api-key
EVOLUTION_INSTANCE=your-instance-name`}
            </pre>
          </div>
        </div>

        {/* About */}
        <div className="bg-white rounded-xl shadow-sm p-6 lg:col-span-2">
          <h2 className="text-lg font-semibold text-gray-900 mb-4">About</h2>
          <div className="text-gray-600 space-y-2">
            <p><strong>Elections Campaign Management System</strong></p>
            <p>Version 1.0.0</p>
            <p className="text-sm">
              A comprehensive system for managing elections, members, and WhatsApp communications
              using Evolution API integration.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Settings;
