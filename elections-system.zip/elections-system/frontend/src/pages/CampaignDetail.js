import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import {
  getCampaign,
  updateCampaign,
  getCampaignMembers,
  addMembersToCampaign,
  removeMemberFromCampaign,
  addAllMembersToCampaign,
  getMembers
} from '../services/api';
import {
  ArrowLeft,
  Save,
  Users,
  UserPlus,
  Trash2,
  X,
  Send,
  Phone,
  MapPin
} from 'lucide-react';

const CampaignDetail = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const [campaign, setCampaign] = useState(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [activeTab, setActiveTab] = useState('details');
  const [campaignMembers, setCampaignMembers] = useState([]);
  const [showAddMembersModal, setShowAddMembersModal] = useState(false);
  const [availableMembers, setAvailableMembers] = useState([]);
  const [selectedMembers, setSelectedMembers] = useState([]);

  useEffect(() => {
    loadCampaign();
  }, [id]);

  useEffect(() => {
    if (activeTab === 'members') {
      loadCampaignMembers();
    }
  }, [activeTab]);

  const loadCampaign = async () => {
    try {
      const response = await getCampaign(id);
      setCampaign(response.data);
    } catch (error) {
      console.error('Failed to load campaign:', error);
    } finally {
      setLoading(false);
    }
  };

  const loadCampaignMembers = async () => {
    try {
      const response = await getCampaignMembers(id);
      setCampaignMembers(response.data);
    } catch (error) {
      console.error('Failed to load members:', error);
    }
  };

  const loadAvailableMembers = async () => {
    try {
      const response = await getMembers({ limit: 1000 });
      const existingIds = campaignMembers.map(m => m.member_id);
      setAvailableMembers(response.data.members.filter(m => !existingIds.includes(m.id)));
    } catch (error) {
      console.error('Failed to load members:', error);
    }
  };

  const handleSave = async () => {
    setSaving(true);
    try {
      await updateCampaign(id, campaign);
      alert('Campaign saved successfully');
    } catch (error) {
      console.error('Failed to save:', error);
      alert('Failed to save campaign');
    } finally {
      setSaving(false);
    }
  };

  const handleOpenAddMembers = async () => {
    await loadAvailableMembers();
    setShowAddMembersModal(true);
  };

  const handleAddMembers = async () => {
    try {
      await addMembersToCampaign(id, selectedMembers);
      setSelectedMembers([]);
      setShowAddMembersModal(false);
      loadCampaignMembers();
      loadCampaign();
    } catch (error) {
      console.error('Failed to add members:', error);
      alert('Failed to add members');
    }
  };

  const handleAddAllMembers = async () => {
    if (!window.confirm('Add all active members to this campaign?')) return;
    try {
      const response = await addAllMembersToCampaign(id);
      alert(`Added ${response.data.count} members to the campaign`);
      loadCampaignMembers();
      loadCampaign();
    } catch (error) {
      console.error('Failed to add all members:', error);
      alert('Failed to add members');
    }
  };

  const handleRemoveMember = async (memberId) => {
    if (window.confirm('Remove this member from the campaign?')) {
      try {
        await removeMemberFromCampaign(id, memberId);
        loadCampaignMembers();
        loadCampaign();
      } catch (error) {
        console.error('Failed to remove member:', error);
      }
    }
  };

  const formatAddress = (member) => {
    const parts = [member.address, member.city, member.state].filter(Boolean);
    return parts.join(', ');
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary-600"></div>
      </div>
    );
  }

  if (!campaign) {
    return (
      <div className="text-center py-12">
        <p className="text-gray-500">Campaign not found</p>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-4">
          <button
            onClick={() => navigate('/campaigns')}
            className="p-2 hover:bg-gray-100 rounded-lg"
          >
            <ArrowLeft className="h-5 w-5" />
          </button>
          <div>
            <h1 className="text-2xl font-bold text-gray-900">{campaign.title}</h1>
            <span className={`inline-block mt-1 px-2 py-1 rounded-full text-xs font-medium ${
              campaign.status === 'active' ? 'bg-green-100 text-green-700' :
              campaign.status === 'draft' ? 'bg-yellow-100 text-yellow-700' :
              campaign.status === 'completed' ? 'bg-blue-100 text-blue-700' :
              'bg-gray-100 text-gray-700'
            }`}>
              {campaign.status}
            </span>
          </div>
        </div>
        <button
          onClick={handleSave}
          disabled={saving}
          className="inline-flex items-center px-4 py-2 bg-primary-600 text-white rounded-lg hover:bg-primary-700 disabled:opacity-50"
        >
          <Save className="h-5 w-5 mr-2" />
          {saving ? 'Saving...' : 'Save Changes'}
        </button>
      </div>

      {/* Tabs */}
      <div className="bg-white rounded-xl shadow-sm">
        <div className="border-b">
          <nav className="flex space-x-8 px-6" aria-label="Tabs">
            {[
              { id: 'details', label: 'Details', icon: null },
              { id: 'members', label: 'Members', icon: Users },
            ].map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`py-4 px-1 border-b-2 font-medium text-sm flex items-center ${
                  activeTab === tab.id
                    ? 'border-primary-500 text-primary-600'
                    : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                }`}
              >
                {tab.icon && <tab.icon className="h-4 w-4 mr-2" />}
                {tab.label}
                {tab.id === 'members' && (
                  <span className="ml-2 bg-gray-100 text-gray-600 px-2 py-0.5 rounded-full text-xs">
                    {campaign.stats?.total_members || 0}
                  </span>
                )}
              </button>
            ))}
          </nav>
        </div>

        <div className="p-6">
          {/* Details Tab */}
          {activeTab === 'details' && (
            <div className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Title</label>
                  <input
                    type="text"
                    value={campaign.title}
                    onChange={(e) => setCampaign({ ...campaign, title: e.target.value })}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Status</label>
                  <select
                    value={campaign.status}
                    onChange={(e) => setCampaign({ ...campaign, status: e.target.value })}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500"
                  >
                    <option value="draft">Draft</option>
                    <option value="active">Active</option>
                    <option value="completed">Completed</option>
                    <option value="cancelled">Cancelled</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Description</label>
                <textarea
                  value={campaign.description || ''}
                  onChange={(e) => setCampaign({ ...campaign, description: e.target.value })}
                  rows={3}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500"
                />
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Start Date</label>
                  <input
                    type="date"
                    value={campaign.start_date?.slice(0, 10) || ''}
                    onChange={(e) => setCampaign({ ...campaign, start_date: e.target.value })}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">End Date</label>
                  <input
                    type="date"
                    value={campaign.end_date?.slice(0, 10) || ''}
                    onChange={(e) => setCampaign({ ...campaign, end_date: e.target.value })}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500"
                  />
                </div>
              </div>

              {/* Stats */}
              <div className="border-t pt-6">
                <h3 className="text-lg font-medium text-gray-900 mb-4">Campaign Statistics</h3>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className="bg-gray-50 rounded-lg p-4">
                    <p className="text-sm text-gray-500">Total Members</p>
                    <p className="text-2xl font-bold text-gray-900">{campaign.stats?.total_members || 0}</p>
                  </div>
                  <div className="bg-gray-50 rounded-lg p-4">
                    <p className="text-sm text-gray-500">Broadcasts Sent</p>
                    <p className="text-2xl font-bold text-gray-900">{campaign.broadcastStats?.total_broadcasts || 0}</p>
                  </div>
                  <div className="bg-gray-50 rounded-lg p-4">
                    <p className="text-sm text-gray-500">Messages Delivered</p>
                    <p className="text-2xl font-bold text-gray-900">{campaign.broadcastStats?.total_sent || 0}</p>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Members Tab */}
          {activeTab === 'members' && (
            <div className="space-y-4">
              <div className="flex justify-between items-center">
                <h3 className="text-lg font-medium text-gray-900">
                  Campaign Members ({campaignMembers.length})
                </h3>
                <div className="flex space-x-2">
                  <button
                    onClick={handleAddAllMembers}
                    className="inline-flex items-center px-3 py-1.5 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 text-sm"
                  >
                    <Users className="h-4 w-4 mr-1" />
                    Add All Members
                  </button>
                  <button
                    onClick={handleOpenAddMembers}
                    className="inline-flex items-center px-3 py-1.5 bg-primary-600 text-white rounded-lg hover:bg-primary-700 text-sm"
                  >
                    <UserPlus className="h-4 w-4 mr-1" />
                    Add Members
                  </button>
                </div>
              </div>

              {campaignMembers.length > 0 ? (
                <div className="overflow-x-auto">
                  <table className="min-w-full divide-y divide-gray-200">
                    <thead className="bg-gray-50">
                      <tr>
                        <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Name</th>
                        <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Contact</th>
                        <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Organization</th>
                        <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Address</th>
                        <th className="px-4 py-3"></th>
                      </tr>
                    </thead>
                    <tbody className="bg-white divide-y divide-gray-200">
                      {campaignMembers.map((member) => (
                        <tr key={member.id}>
                          <td className="px-4 py-3">
                            <p className="font-medium text-gray-900">{member.full_name}</p>
                            {member.member_id && (
                              <p className="text-xs text-gray-500">ID: {member.member_id}</p>
                            )}
                          </td>
                          <td className="px-4 py-3">
                            <div className="flex items-center text-sm text-gray-500">
                              <Phone className="h-3 w-3 mr-1" />
                              {member.phone}
                            </div>
                            {member.email && (
                              <p className="text-xs text-gray-400">{member.email}</p>
                            )}
                          </td>
                          <td className="px-4 py-3 text-sm text-gray-500">
                            {member.organization}
                            {member.department && (
                              <span className="text-xs text-gray-400 block">{member.department}</span>
                            )}
                          </td>
                          <td className="px-4 py-3">
                            {(member.address || member.city) && (
                              <div className="flex items-start text-sm text-gray-500 max-w-xs">
                                <MapPin className="h-3 w-3 mr-1 mt-0.5 flex-shrink-0" />
                                <span className="truncate text-xs">{formatAddress(member)}</span>
                              </div>
                            )}
                          </td>
                          <td className="px-4 py-3">
                            <button
                              onClick={() => handleRemoveMember(member.member_id)}
                              className="text-red-600 hover:text-red-700"
                            >
                              <Trash2 className="h-4 w-4" />
                            </button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              ) : (
                <div className="text-center py-8 text-gray-500">
                  <Users className="h-12 w-12 mx-auto mb-2 opacity-50" />
                  <p>No members added to this campaign</p>
                </div>
              )}
            </div>
          )}
        </div>
      </div>

      {/* Add Members Modal */}
      {showAddMembersModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-xl shadow-xl max-w-2xl w-full max-h-[80vh] overflow-hidden flex flex-col">
            <div className="p-6 border-b flex items-center justify-between">
              <h2 className="text-xl font-semibold">Add Members to Campaign</h2>
              <button onClick={() => setShowAddMembersModal(false)}>
                <X className="h-5 w-5" />
              </button>
            </div>
            <div className="p-6 overflow-y-auto flex-1">
              <p className="text-sm text-gray-500 mb-4">
                Select members to add ({selectedMembers.length} selected)
              </p>
              <div className="space-y-2">
                {availableMembers.map((member) => (
                  <label
                    key={member.id}
                    className="flex items-center p-3 bg-gray-50 rounded-lg cursor-pointer hover:bg-gray-100"
                  >
                    <input
                      type="checkbox"
                      checked={selectedMembers.includes(member.id)}
                      onChange={(e) => {
                        if (e.target.checked) {
                          setSelectedMembers([...selectedMembers, member.id]);
                        } else {
                          setSelectedMembers(selectedMembers.filter(id => id !== member.id));
                        }
                      }}
                      className="h-4 w-4 text-primary-600 rounded"
                    />
                    <div className="ml-3 flex-1">
                      <p className="font-medium text-gray-900">{member.full_name}</p>
                      <p className="text-sm text-gray-500">{member.phone} • {member.organization || 'No organization'}</p>
                      {member.city && (
                        <p className="text-xs text-gray-400">{member.city}, {member.state}</p>
                      )}
                    </div>
                  </label>
                ))}
              </div>
              {availableMembers.length === 0 && (
                <p className="text-center py-8 text-gray-500">All members are already added</p>
              )}
            </div>
            <div className="p-6 border-t flex justify-end space-x-3">
              <button
                onClick={() => setShowAddMembersModal(false)}
                className="px-4 py-2 text-gray-700 hover:bg-gray-100 rounded-lg"
              >
                Cancel
              </button>
              <button
                onClick={handleAddMembers}
                disabled={selectedMembers.length === 0}
                className="px-4 py-2 bg-primary-600 text-white rounded-lg hover:bg-primary-700 disabled:opacity-50"
              >
                Add {selectedMembers.length} Members
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default CampaignDetail;
