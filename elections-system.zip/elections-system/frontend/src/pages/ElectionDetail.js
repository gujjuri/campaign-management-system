import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import {
  getElection,
  updateElection,
  addCandidates,
  deleteCandidate,
  getElectionMembers,
  addMembersToElection,
  removeMemberFromElection,
  sendVotingLinks,
  sendReminders,
  getElectionResults,
  getMembers
} from '../services/api';
import {
  ArrowLeft,
  Save,
  Plus,
  Trash2,
  Users,
  Send,
  Bell,
  BarChart3,
  CheckCircle,
  Clock,
  UserPlus,
  X
} from 'lucide-react';

const ElectionDetail = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const [election, setElection] = useState(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [activeTab, setActiveTab] = useState('details');
  const [electionMembers, setElectionMembers] = useState([]);
  const [results, setResults] = useState(null);
  const [showAddCandidateModal, setShowAddCandidateModal] = useState(false);
  const [showAddMembersModal, setShowAddMembersModal] = useState(false);
  const [availableMembers, setAvailableMembers] = useState([]);
  const [selectedMembers, setSelectedMembers] = useState([]);
  const [newCandidate, setNewCandidate] = useState({ name: '', description: '' });
  const [sendingLinks, setSendingLinks] = useState(false);
  const [sendingReminders, setSendingReminders] = useState(false);

  useEffect(() => {
    loadElection();
  }, [id]);

  useEffect(() => {
    if (activeTab === 'members') {
      loadElectionMembers();
    } else if (activeTab === 'results') {
      loadResults();
    }
  }, [activeTab]);

  const loadElection = async () => {
    try {
      const response = await getElection(id);
      setElection(response.data);
    } catch (error) {
      console.error('Failed to load election:', error);
    } finally {
      setLoading(false);
    }
  };

  const loadElectionMembers = async () => {
    try {
      const response = await getElectionMembers(id);
      setElectionMembers(response.data);
    } catch (error) {
      console.error('Failed to load members:', error);
    }
  };

  const loadResults = async () => {
    try {
      const response = await getElectionResults(id);
      setResults(response.data);
    } catch (error) {
      console.error('Failed to load results:', error);
    }
  };

  const loadAvailableMembers = async () => {
    try {
      const response = await getMembers({ limit: 1000 });
      const existingIds = electionMembers.map(m => m.member_id);
      setAvailableMembers(response.data.members.filter(m => !existingIds.includes(m.id)));
    } catch (error) {
      console.error('Failed to load members:', error);
    }
  };

  const handleSave = async () => {
    setSaving(true);
    try {
      await updateElection(id, election);
      alert('Election saved successfully');
    } catch (error) {
      console.error('Failed to save:', error);
      alert('Failed to save election');
    } finally {
      setSaving(false);
    }
  };

  const handleAddCandidate = async () => {
    try {
      await addCandidates(id, [newCandidate]);
      setNewCandidate({ name: '', description: '' });
      setShowAddCandidateModal(false);
      loadElection();
    } catch (error) {
      console.error('Failed to add candidate:', error);
      alert('Failed to add candidate');
    }
  };

  const handleDeleteCandidate = async (candidateId) => {
    if (window.confirm('Are you sure you want to delete this candidate?')) {
      try {
        await deleteCandidate(id, candidateId);
        loadElection();
      } catch (error) {
        console.error('Failed to delete candidate:', error);
      }
    }
  };

  const handleOpenAddMembers = async () => {
    await loadAvailableMembers();
    setShowAddMembersModal(true);
  };

  const handleAddMembers = async () => {
    try {
      await addMembersToElection(id, selectedMembers);
      setSelectedMembers([]);
      setShowAddMembersModal(false);
      loadElectionMembers();
    } catch (error) {
      console.error('Failed to add members:', error);
      alert('Failed to add members');
    }
  };

  const handleRemoveMember = async (memberId) => {
    if (window.confirm('Remove this member from the election?')) {
      try {
        await removeMemberFromElection(id, memberId);
        loadElectionMembers();
      } catch (error) {
        console.error('Failed to remove member:', error);
      }
    }
  };

  const handleSendVotingLinks = async () => {
    if (!window.confirm('Send voting links to all members who haven\'t voted yet?')) return;
    setSendingLinks(true);
    try {
      const response = await sendVotingLinks(id);
      alert(`Sent ${response.data.sent} voting links (${response.data.failed} failed)`);
    } catch (error) {
      console.error('Failed to send voting links:', error);
      alert('Failed to send voting links');
    } finally {
      setSendingLinks(false);
    }
  };

  const handleSendReminders = async () => {
    if (!window.confirm('Send reminders to all members who haven\'t voted yet?')) return;
    setSendingReminders(true);
    try {
      const response = await sendReminders(id);
      alert(`Sent ${response.data.sent} reminders (${response.data.failed} failed)`);
    } catch (error) {
      console.error('Failed to send reminders:', error);
      alert('Failed to send reminders');
    } finally {
      setSendingReminders(false);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary-600"></div>
      </div>
    );
  }

  if (!election) {
    return (
      <div className="text-center py-12">
        <p className="text-gray-500">Election not found</p>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-4">
          <button
            onClick={() => navigate('/elections')}
            className="p-2 hover:bg-gray-100 rounded-lg"
          >
            <ArrowLeft className="h-5 w-5" />
          </button>
          <div>
            <h1 className="text-2xl font-bold text-gray-900">{election.title}</h1>
            <span className={`inline-block mt-1 px-2 py-1 rounded-full text-xs font-medium ${
              election.status === 'active' ? 'bg-green-100 text-green-700' :
              election.status === 'draft' ? 'bg-yellow-100 text-yellow-700' :
              'bg-gray-100 text-gray-700'
            }`}>
              {election.status}
            </span>
          </div>
        </div>
        <button
          onClick={handleSave}
          disabled={saving}
          className="inline-flex items-center px-4 py-2 bg-primary-600 text-white rounded-lg hover:bg-primary-700 disabled:opacity-50"
        >
          <Save className="h-5 w-5 mr-2" />
          {saving ? 'Saving...' : 'Save Changes'}
        </button>
      </div>

      {/* Tabs */}
      <div className="bg-white rounded-xl shadow-sm">
        <div className="border-b">
          <nav className="flex space-x-8 px-6" aria-label="Tabs">
            {[
              { id: 'details', label: 'Details', icon: null },
              { id: 'candidates', label: 'Candidates', icon: null },
              { id: 'members', label: 'Members', icon: Users },
              { id: 'results', label: 'Results', icon: BarChart3 },
            ].map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`py-4 px-1 border-b-2 font-medium text-sm flex items-center ${
                  activeTab === tab.id
                    ? 'border-primary-500 text-primary-600'
                    : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                }`}
              >
                {tab.icon && <tab.icon className="h-4 w-4 mr-2" />}
                {tab.label}
              </button>
            ))}
          </nav>
        </div>

        <div className="p-6">
          {/* Details Tab */}
          {activeTab === 'details' && (
            <div className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Title</label>
                  <input
                    type="text"
                    value={election.title}
                    onChange={(e) => setElection({ ...election, title: e.target.value })}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Status</label>
                  <select
                    value={election.status}
                    onChange={(e) => setElection({ ...election, status: e.target.value })}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500"
                  >
                    <option value="draft">Draft</option>
                    <option value="active">Active</option>
                    <option value="closed">Closed</option>
                    <option value="cancelled">Cancelled</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Description</label>
                <textarea
                  value={election.description || ''}
                  onChange={(e) => setElection({ ...election, description: e.target.value })}
                  rows={3}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500"
                />
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Start Date</label>
                  <input
                    type="datetime-local"
                    value={election.start_date?.slice(0, 16)}
                    onChange={(e) => setElection({ ...election, start_date: e.target.value })}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">End Date</label>
                  <input
                    type="datetime-local"
                    value={election.end_date?.slice(0, 16)}
                    onChange={(e) => setElection({ ...election, end_date: e.target.value })}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500"
                  />
                </div>
              </div>

              {/* Quick Actions */}
              <div className="border-t pt-6">
                <h3 className="text-lg font-medium text-gray-900 mb-4">Quick Actions</h3>
                <div className="flex flex-wrap gap-3">
                  <button
                    onClick={handleSendVotingLinks}
                    disabled={sendingLinks || election.status !== 'active'}
                    className="inline-flex items-center px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 disabled:opacity-50"
                  >
                    <Send className="h-4 w-4 mr-2" />
                    {sendingLinks ? 'Sending...' : 'Send Voting Links'}
                  </button>
                  <button
                    onClick={handleSendReminders}
                    disabled={sendingReminders || election.status !== 'active'}
                    className="inline-flex items-center px-4 py-2 bg-orange-600 text-white rounded-lg hover:bg-orange-700 disabled:opacity-50"
                  >
                    <Bell className="h-4 w-4 mr-2" />
                    {sendingReminders ? 'Sending...' : 'Send Reminders'}
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* Candidates Tab */}
          {activeTab === 'candidates' && (
            <div className="space-y-4">
              <div className="flex justify-between items-center">
                <h3 className="text-lg font-medium text-gray-900">Candidates</h3>
                <button
                  onClick={() => setShowAddCandidateModal(true)}
                  className="inline-flex items-center px-3 py-2 bg-primary-600 text-white rounded-lg hover:bg-primary-700 text-sm"
                >
                  <Plus className="h-4 w-4 mr-1" />
                  Add Candidate
                </button>
              </div>

              {election.candidates?.length > 0 ? (
                <div className="space-y-3">
                  {election.candidates.map((candidate) => (
                    <div
                      key={candidate.id}
                      className="flex items-center justify-between p-4 bg-gray-50 rounded-lg"
                    >
                      <div>
                        <p className="font-medium text-gray-900">{candidate.name}</p>
                        {candidate.description && (
                          <p className="text-sm text-gray-500">{candidate.description}</p>
                        )}
                        <p className="text-xs text-gray-400 mt-1">
                          {candidate.vote_count || 0} votes
                        </p>
                      </div>
                      <button
                        onClick={() => handleDeleteCandidate(candidate.id)}
                        className="p-2 text-red-600 hover:bg-red-50 rounded"
                      >
                        <Trash2 className="h-4 w-4" />
                      </button>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-8 text-gray-500">
                  No candidates added yet
                </div>
              )}
            </div>
          )}

          {/* Members Tab */}
          {activeTab === 'members' && (
            <div className="space-y-4">
              <div className="flex justify-between items-center">
                <h3 className="text-lg font-medium text-gray-900">
                  Election Members ({electionMembers.length})
                </h3>
                <button
                  onClick={handleOpenAddMembers}
                  className="inline-flex items-center px-3 py-2 bg-primary-600 text-white rounded-lg hover:bg-primary-700 text-sm"
                >
                  <UserPlus className="h-4 w-4 mr-1" />
                  Add Members
                </button>
              </div>

              {electionMembers.length > 0 ? (
                <div className="overflow-x-auto">
                  <table className="min-w-full divide-y divide-gray-200">
                    <thead className="bg-gray-50">
                      <tr>
                        <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Name</th>
                        <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Phone</th>
                        <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Status</th>
                        <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Reminders</th>
                        <th className="px-4 py-3"></th>
                      </tr>
                    </thead>
                    <tbody className="bg-white divide-y divide-gray-200">
                      {electionMembers.map((member) => (
                        <tr key={member.id}>
                          <td className="px-4 py-3">
                            <p className="font-medium text-gray-900">{member.full_name}</p>
                            <p className="text-sm text-gray-500">{member.organization}</p>
                          </td>
                          <td className="px-4 py-3 text-sm text-gray-500">{member.phone}</td>
                          <td className="px-4 py-3">
                            {member.has_voted ? (
                              <span className="inline-flex items-center text-green-600 text-sm">
                                <CheckCircle className="h-4 w-4 mr-1" />
                                Voted
                              </span>
                            ) : (
                              <span className="inline-flex items-center text-yellow-600 text-sm">
                                <Clock className="h-4 w-4 mr-1" />
                                Pending
                              </span>
                            )}
                          </td>
                          <td className="px-4 py-3 text-sm text-gray-500">
                            {member.reminder_count || 0}
                          </td>
                          <td className="px-4 py-3">
                            <button
                              onClick={() => handleRemoveMember(member.member_id)}
                              className="text-red-600 hover:text-red-700"
                            >
                              <Trash2 className="h-4 w-4" />
                            </button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              ) : (
                <div className="text-center py-8 text-gray-500">
                  No members added to this election
                </div>
              )}
            </div>
          )}

          {/* Results Tab */}
          {activeTab === 'results' && (
            <div className="space-y-6">
              {results ? (
                <>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div className="bg-gray-50 rounded-lg p-4">
                      <p className="text-sm text-gray-500">Total Eligible</p>
                      <p className="text-2xl font-bold text-gray-900">{results.stats?.total_members || 0}</p>
                    </div>
                    <div className="bg-green-50 rounded-lg p-4">
                      <p className="text-sm text-green-600">Voted</p>
                      <p className="text-2xl font-bold text-green-700">{results.stats?.voted_count || 0}</p>
                    </div>
                    <div className="bg-blue-50 rounded-lg p-4">
                      <p className="text-sm text-blue-600">Turnout</p>
                      <p className="text-2xl font-bold text-blue-700">{results.turnout_percentage}%</p>
                    </div>
                  </div>

                  <div>
                    <h3 className="text-lg font-medium text-gray-900 mb-4">Vote Distribution</h3>
                    <div className="space-y-3">
                      {results.results?.map((candidate, index) => {
                        const totalVotes = results.results.reduce((sum, c) => sum + c.vote_count, 0);
                        const percentage = totalVotes > 0 ? (candidate.vote_count / totalVotes) * 100 : 0;
                        return (
                          <div key={candidate.id}>
                            <div className="flex items-center justify-between mb-1">
                              <span className="font-medium text-gray-900">
                                {index + 1}. {candidate.name}
                              </span>
                              <span className="text-sm text-gray-500">
                                {candidate.vote_count} votes ({percentage.toFixed(1)}%)
                              </span>
                            </div>
                            <div className="w-full bg-gray-200 rounded-full h-3">
                              <div
                                className={`h-3 rounded-full ${index === 0 ? 'bg-green-500' : 'bg-primary-500'}`}
                                style={{ width: `${percentage}%` }}
                              />
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                </>
              ) : (
                <div className="text-center py-8 text-gray-500">
                  Loading results...
                </div>
              )}
            </div>
          )}
        </div>
      </div>

      {/* Add Candidate Modal */}
      {showAddCandidateModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-xl shadow-xl max-w-md w-full">
            <div className="p-6 border-b flex items-center justify-between">
              <h2 className="text-xl font-semibold">Add Candidate</h2>
              <button onClick={() => setShowAddCandidateModal(false)}>
                <X className="h-5 w-5" />
              </button>
            </div>
            <div className="p-6 space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Name *</label>
                <input
                  type="text"
                  value={newCandidate.name}
                  onChange={(e) => setNewCandidate({ ...newCandidate, name: e.target.value })}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Description</label>
                <textarea
                  value={newCandidate.description}
                  onChange={(e) => setNewCandidate({ ...newCandidate, description: e.target.value })}
                  rows={3}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg"
                />
              </div>
              <div className="flex justify-end space-x-3">
                <button
                  onClick={() => setShowAddCandidateModal(false)}
                  className="px-4 py-2 text-gray-700 hover:bg-gray-100 rounded-lg"
                >
                  Cancel
                </button>
                <button
                  onClick={handleAddCandidate}
                  disabled={!newCandidate.name}
                  className="px-4 py-2 bg-primary-600 text-white rounded-lg hover:bg-primary-700 disabled:opacity-50"
                >
                  Add Candidate
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Add Members Modal */}
      {showAddMembersModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-xl shadow-xl max-w-2xl w-full max-h-[80vh] overflow-hidden flex flex-col">
            <div className="p-6 border-b flex items-center justify-between">
              <h2 className="text-xl font-semibold">Add Members to Election</h2>
              <button onClick={() => setShowAddMembersModal(false)}>
                <X className="h-5 w-5" />
              </button>
            </div>
            <div className="p-6 overflow-y-auto flex-1">
              <p className="text-sm text-gray-500 mb-4">
                Select members to add ({selectedMembers.length} selected)
              </p>
              <div className="space-y-2">
                {availableMembers.map((member) => (
                  <label
                    key={member.id}
                    className="flex items-center p-3 bg-gray-50 rounded-lg cursor-pointer hover:bg-gray-100"
                  >
                    <input
                      type="checkbox"
                      checked={selectedMembers.includes(member.id)}
                      onChange={(e) => {
                        if (e.target.checked) {
                          setSelectedMembers([...selectedMembers, member.id]);
                        } else {
                          setSelectedMembers(selectedMembers.filter(id => id !== member.id));
                        }
                      }}
                      className="h-4 w-4 text-primary-600 rounded"
                    />
                    <div className="ml-3">
                      <p className="font-medium text-gray-900">{member.full_name}</p>
                      <p className="text-sm text-gray-500">{member.phone} • {member.organization}</p>
                    </div>
                  </label>
                ))}
              </div>
              {availableMembers.length === 0 && (
                <p className="text-center py-8 text-gray-500">All members are already added</p>
              )}
            </div>
            <div className="p-6 border-t flex justify-end space-x-3">
              <button
                onClick={() => setShowAddMembersModal(false)}
                className="px-4 py-2 text-gray-700 hover:bg-gray-100 rounded-lg"
              >
                Cancel
              </button>
              <button
                onClick={handleAddMembers}
                disabled={selectedMembers.length === 0}
                className="px-4 py-2 bg-primary-600 text-white rounded-lg hover:bg-primary-700 disabled:opacity-50"
              >
                Add {selectedMembers.length} Members
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default ElectionDetail;
