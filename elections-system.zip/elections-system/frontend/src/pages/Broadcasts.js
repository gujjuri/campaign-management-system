import React, { useState, useEffect, useRef } from 'react';
import { Link } from 'react-router-dom';
import {
  getBroadcasts,
  createBroadcast,
  createMediaBroadcast,
  deleteBroadcast,
  getElections
} from '../services/api';
import {
  Plus,
  Search,
  Send,
  Image,
  FileText,
  MoreVertical,
  Eye,
  Trash2,
  MessageSquare,
  X,
  Upload
} from 'lucide-react';

const Broadcasts = () => {
  const [broadcasts, setBroadcasts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [showModal, setShowModal] = useState(false);
  const [activeMenu, setActiveMenu] = useState(null);
  const [elections, setElections] = useState([]);
  const [messageType, setMessageType] = useState('text');
  const [selectedFile, setSelectedFile] = useState(null);
  const fileInputRef = useRef(null);

  const [formData, setFormData] = useState({
    title: '',
    content: '',
    election_id: '',
    target_filter: ''
  });

  useEffect(() => {
    loadBroadcasts();
    loadElections();
  }, []);

  const loadBroadcasts = async () => {
    try {
      const response = await getBroadcasts();
      setBroadcasts(response.data);
    } catch (error) {
      console.error('Failed to load broadcasts:', error);
    } finally {
      setLoading(false);
    }
  };

  const loadElections = async () => {
    try {
      const response = await getElections();
      setElections(response.data);
    } catch (error) {
      console.error('Failed to load elections:', error);
    }
  };

  const handleCreate = async (e) => {
    e.preventDefault();
    try {
      if (messageType === 'text') {
        await createBroadcast(formData);
      } else {
        const data = new FormData();
        data.append('title', formData.title);
        data.append('caption', formData.content);
        data.append('message_type', messageType);
        data.append('election_id', formData.election_id);
        data.append('target_filter', formData.target_filter);
        if (selectedFile) {
          data.append('media', selectedFile);
        }
        await createMediaBroadcast(data);
      }
      setShowModal(false);
      resetForm();
      loadBroadcasts();
    } catch (error) {
      console.error('Failed to create broadcast:', error);
      alert('Failed to create broadcast');
    }
  };

  const handleDelete = async (id) => {
    if (window.confirm('Are you sure you want to delete this broadcast?')) {
      try {
        await deleteBroadcast(id);
        loadBroadcasts();
      } catch (error) {
        console.error('Failed to delete broadcast:', error);
      }
    }
    setActiveMenu(null);
  };

  const resetForm = () => {
    setFormData({
      title: '',
      content: '',
      election_id: '',
      target_filter: ''
    });
    setMessageType('text');
    setSelectedFile(null);
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'completed': return 'bg-green-100 text-green-700';
      case 'sending': return 'bg-blue-100 text-blue-700';
      case 'draft': return 'bg-yellow-100 text-yellow-700';
      case 'failed': return 'bg-red-100 text-red-700';
      default: return 'bg-gray-100 text-gray-700';
    }
  };

  const getTypeIcon = (type) => {
    switch (type) {
      case 'image': return <Image className="h-4 w-4" />;
      case 'document': return <FileText className="h-4 w-4" />;
      default: return <MessageSquare className="h-4 w-4" />;
    }
  };

  const filteredBroadcasts = broadcasts.filter(b =>
    b.title.toLowerCase().includes(searchTerm.toLowerCase())
  );

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary-600"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <h1 className="text-2xl font-bold text-gray-900">Broadcasts</h1>
        <button
          onClick={() => setShowModal(true)}
          className="inline-flex items-center px-4 py-2 bg-primary-600 text-white rounded-lg hover:bg-primary-700"
        >
          <Plus className="h-5 w-5 mr-2" />
          Create Broadcast
        </button>
      </div>

      {/* Search */}
      <div className="bg-white rounded-xl shadow-sm p-4">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-gray-400" />
          <input
            type="text"
            placeholder="Search broadcasts..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500"
          />
        </div>
      </div>

      {/* Broadcasts List */}
      {filteredBroadcasts.length > 0 ? (
        <div className="bg-white rounded-xl shadow-sm overflow-hidden">
          <div className="divide-y">
            {filteredBroadcasts.map((broadcast) => (
              <div key={broadcast.id} className="p-4 hover:bg-gray-50">
                <div className="flex items-start justify-between">
                  <div className="flex items-start space-x-4">
                    <div className={`p-2 rounded-lg ${
                      broadcast.message_type === 'image' ? 'bg-purple-100 text-purple-600' :
                      broadcast.message_type === 'document' ? 'bg-orange-100 text-orange-600' :
                      'bg-blue-100 text-blue-600'
                    }`}>
                      {getTypeIcon(broadcast.message_type)}
                    </div>
                    <div className="flex-1">
                      <div className="flex items-center space-x-2">
                        <h3 className="font-medium text-gray-900">{broadcast.title}</h3>
                        <span className={`px-2 py-0.5 rounded-full text-xs font-medium ${getStatusColor(broadcast.status)}`}>
                          {broadcast.status}
                        </span>
                      </div>
                      {broadcast.content && (
                        <p className="text-sm text-gray-500 mt-1 line-clamp-2">
                          {broadcast.content}
                        </p>
                      )}
                      <div className="flex items-center space-x-4 mt-2 text-xs text-gray-500">
                        <span>{broadcast.sent_count || 0} / {broadcast.total_recipients || 0} sent</span>
                        <span>{new Date(broadcast.created_at).toLocaleDateString()}</span>
                        {broadcast.election_title && (
                          <span className="text-primary-600">Election: {broadcast.election_title}</span>
                        )}
                      </div>
                    </div>
                  </div>
                  <div className="relative">
                    <button
                      onClick={() => setActiveMenu(activeMenu === broadcast.id ? null : broadcast.id)}
                      className="p-1 hover:bg-gray-100 rounded"
                    >
                      <MoreVertical className="h-5 w-5 text-gray-500" />
                    </button>
                    {activeMenu === broadcast.id && (
                      <>
                        <div className="fixed inset-0 z-10" onClick={() => setActiveMenu(null)} />
                        <div className="absolute right-0 mt-1 w-48 bg-white rounded-lg shadow-lg py-1 z-20">
                          <Link
                            to={`/broadcasts/${broadcast.id}`}
                            className="flex items-center px-4 py-2 text-sm text-gray-700 hover:bg-gray-100"
                          >
                            <Eye className="h-4 w-4 mr-2" /> View Details
                          </Link>
                          <button
                            onClick={() => handleDelete(broadcast.id)}
                            className="w-full flex items-center px-4 py-2 text-sm text-red-600 hover:bg-gray-100"
                          >
                            <Trash2 className="h-4 w-4 mr-2" /> Delete
                          </button>
                        </div>
                      </>
                    )}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      ) : (
        <div className="bg-white rounded-xl shadow-sm p-12 text-center">
          <Send className="h-12 w-12 mx-auto text-gray-400 mb-4" />
          <h3 className="text-lg font-medium text-gray-900 mb-2">No broadcasts found</h3>
          <p className="text-gray-500 mb-4">Create your first broadcast to reach your members.</p>
          <button
            onClick={() => setShowModal(true)}
            className="inline-flex items-center px-4 py-2 bg-primary-600 text-white rounded-lg hover:bg-primary-700"
          >
            <Plus className="h-5 w-5 mr-2" />
            Create Broadcast
          </button>
        </div>
      )}

      {/* Create Modal */}
      {showModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-xl shadow-xl max-w-lg w-full max-h-[90vh] overflow-y-auto">
            <div className="p-6 border-b flex items-center justify-between">
              <h2 className="text-xl font-semibold">Create New Broadcast</h2>
              <button onClick={() => { setShowModal(false); resetForm(); }}>
                <X className="h-5 w-5" />
              </button>
            </div>
            <form onSubmit={handleCreate} className="p-6 space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Title *</label>
                <input
                  type="text"
                  value={formData.title}
                  onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500"
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Message Type</label>
                <div className="flex space-x-2">
                  {[
                    { id: 'text', label: 'Text', icon: MessageSquare },
                    { id: 'image', label: 'Image', icon: Image },
                    { id: 'document', label: 'Document', icon: FileText },
                  ].map((type) => (
                    <button
                      key={type.id}
                      type="button"
                      onClick={() => setMessageType(type.id)}
                      className={`flex-1 flex items-center justify-center px-4 py-2 border rounded-lg ${
                        messageType === type.id
                          ? 'border-primary-500 bg-primary-50 text-primary-700'
                          : 'border-gray-300 hover:bg-gray-50'
                      }`}
                    >
                      <type.icon className="h-4 w-4 mr-2" />
                      {type.label}
                    </button>
                  ))}
                </div>
              </div>

              {messageType !== 'text' && (
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    {messageType === 'image' ? 'Image' : 'Document'} File *
                  </label>
                  <input
                    type="file"
                    ref={fileInputRef}
                    onChange={(e) => setSelectedFile(e.target.files[0])}
                    accept={messageType === 'image' ? 'image/*' : '.pdf,.doc,.docx,.xls,.xlsx'}
                    className="hidden"
                  />
                  <button
                    type="button"
                    onClick={() => fileInputRef.current?.click()}
                    className="w-full py-4 border-2 border-dashed border-gray-300 rounded-lg hover:border-primary-500 transition-colors"
                  >
                    {selectedFile ? (
                      <div className="flex items-center justify-center">
                        <FileText className="h-5 w-5 mr-2 text-gray-500" />
                        <span className="text-gray-700">{selectedFile.name}</span>
                      </div>
                    ) : (
                      <div className="text-center">
                        <Upload className="h-6 w-6 mx-auto text-gray-400 mb-1" />
                        <p className="text-sm text-gray-500">Click to upload</p>
                      </div>
                    )}
                  </button>
                </div>
              )}

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  {messageType === 'text' ? 'Message *' : 'Caption'}
                </label>
                <textarea
                  value={formData.content}
                  onChange={(e) => setFormData({ ...formData, content: e.target.value })}
                  rows={4}
                  placeholder="Use {name} to personalize with member's name"
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500"
                  required={messageType === 'text'}
                />
                <p className="text-xs text-gray-500 mt-1">
                  Tip: Use {'{name}'} to include the member's name in the message
                </p>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Link to Election (Optional)
                </label>
                <select
                  value={formData.election_id}
                  onChange={(e) => setFormData({ ...formData, election_id: e.target.value })}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500"
                >
                  <option value="">No election</option>
                  {elections.map((election) => (
                    <option key={election.id} value={election.id}>
                      {election.title}
                    </option>
                  ))}
                </select>
              </div>

              <div className="flex justify-end space-x-3 pt-4">
                <button
                  type="button"
                  onClick={() => { setShowModal(false); resetForm(); }}
                  className="px-4 py-2 text-gray-700 hover:bg-gray-100 rounded-lg"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-primary-600 text-white rounded-lg hover:bg-primary-700"
                >
                  Create Broadcast
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default Broadcasts;
