import React, { useState, useEffect } from 'react';
import { useParams } from 'react-router-dom';
import { getVotingPage, submitVote } from '../services/api';
import { Vote, CheckCircle, AlertCircle, Clock } from 'lucide-react';

const VotingPage = () => {
  const { token } = useParams();
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [selections, setSelections] = useState([]);
  const [submitting, setSubmitting] = useState(false);
  const [submitted, setSubmitted] = useState(false);

  useEffect(() => {
    loadVotingPage();
  }, [token]);

  const loadVotingPage = async () => {
    try {
      const response = await getVotingPage(token);
      setData(response.data);
    } catch (err) {
      setError(err.response?.data?.error || 'Failed to load voting page');
    } finally {
      setLoading(false);
    }
  };

  const handleSelect = (candidateId) => {
    if (!data) return;

    if (data.election.election_type === 'single') {
      setSelections([candidateId]);
    } else if (data.election.election_type === 'multiple') {
      if (selections.includes(candidateId)) {
        setSelections(selections.filter(id => id !== candidateId));
      } else if (selections.length < data.election.max_selections) {
        setSelections([...selections, candidateId]);
      }
    }
  };

  const handleYesNoSelect = (candidateId, value) => {
    const existing = selections.find(s => s.candidate_id === candidateId);
    if (existing) {
      setSelections(selections.map(s => 
        s.candidate_id === candidateId ? { ...s, value } : s
      ));
    } else {
      setSelections([...selections, { candidate_id: candidateId, value }]);
    }
  };

  const handleSubmit = async () => {
    if (selections.length === 0) {
      alert('Please make a selection');
      return;
    }

    if (!window.confirm('Are you sure you want to submit your vote? This action cannot be undone.')) {
      return;
    }

    setSubmitting(true);
    try {
      await submitVote(token, selections);
      setSubmitted(true);
    } catch (err) {
      alert(err.response?.data?.error || 'Failed to submit vote');
    } finally {
      setSubmitting(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-100 flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary-600"></div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-screen bg-gray-100 flex items-center justify-center p-4">
        <div className="bg-white rounded-xl shadow-lg p-8 max-w-md w-full text-center">
          <AlertCircle className="h-16 w-16 mx-auto text-red-500 mb-4" />
          <h1 className="text-xl font-bold text-gray-900 mb-2">Unable to Vote</h1>
          <p className="text-gray-600">{error}</p>
        </div>
      </div>
    );
  }

  if (submitted) {
    return (
      <div className="min-h-screen bg-gray-100 flex items-center justify-center p-4">
        <div className="bg-white rounded-xl shadow-lg p-8 max-w-md w-full text-center">
          <CheckCircle className="h-16 w-16 mx-auto text-green-500 mb-4" />
          <h1 className="text-xl font-bold text-gray-900 mb-2">Vote Submitted!</h1>
          <p className="text-gray-600">
            Thank you for participating in the election. Your vote has been recorded successfully.
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-100 py-8 px-4">
      <div className="max-w-2xl mx-auto">
        {/* Header */}
        <div className="bg-white rounded-xl shadow-lg p-6 mb-6">
          <div className="flex items-center justify-center mb-4">
            <div className="w-16 h-16 bg-primary-100 rounded-full flex items-center justify-center">
              <Vote className="h-8 w-8 text-primary-600" />
            </div>
          </div>
          <h1 className="text-2xl font-bold text-gray-900 text-center">
            {data.election.title}
          </h1>
          {data.election.description && (
            <p className="text-gray-600 text-center mt-2">
              {data.election.description}
            </p>
          )}
          <div className="flex items-center justify-center mt-4 text-sm text-gray-500">
            <Clock className="h-4 w-4 mr-1" />
            Voting ends: {new Date(data.election.end_date).toLocaleString()}
          </div>
          <p className="text-center mt-2 text-gray-600">
            Welcome, <span className="font-medium">{data.member_name}</span>
          </p>
        </div>

        {/* Instructions */}
        <div className="bg-blue-50 border border-blue-200 rounded-xl p-4 mb-6">
          <p className="text-blue-800 text-sm">
            {data.election.election_type === 'single' && (
              'Select ONE candidate from the list below.'
            )}
            {data.election.election_type === 'multiple' && (
              `Select up to ${data.election.max_selections} candidates from the list below.`
            )}
            {data.election.election_type === 'yesno' && (
              'Vote Yes, No, or Abstain for each item below.'
            )}
            {data.election.election_type === 'ranked' && (
              'Rank the candidates in order of preference.'
            )}
          </p>
        </div>

        {/* Candidates */}
        <div className="space-y-4 mb-6">
          {data.candidates.map((candidate) => {
            const isSelected = data.election.election_type === 'yesno'
              ? selections.find(s => s.candidate_id === candidate.id)
              : selections.includes(candidate.id);

            return (
              <div
                key={candidate.id}
                className={`bg-white rounded-xl shadow-sm p-4 border-2 transition-all ${
                  isSelected ? 'border-primary-500' : 'border-transparent'
                }`}
              >
                {data.election.election_type === 'yesno' ? (
                  <div>
                    <h3 className="font-medium text-gray-900 mb-2">{candidate.name}</h3>
                    {candidate.description && (
                      <p className="text-sm text-gray-600 mb-3">{candidate.description}</p>
                    )}
                    <div className="flex space-x-2">
                      {['yes', 'no', 'abstain'].map((value) => {
                        const currentValue = selections.find(s => s.candidate_id === candidate.id)?.value;
                        return (
                          <button
                            key={value}
                            onClick={() => handleYesNoSelect(candidate.id, value)}
                            className={`flex-1 py-2 rounded-lg font-medium transition-colors ${
                              currentValue === value
                                ? value === 'yes' ? 'bg-green-500 text-white' :
                                  value === 'no' ? 'bg-red-500 text-white' :
                                  'bg-gray-500 text-white'
                                : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                            }`}
                          >
                            {value.charAt(0).toUpperCase() + value.slice(1)}
                          </button>
                        );
                      })}
                    </div>
                  </div>
                ) : (
                  <button
                    onClick={() => handleSelect(candidate.id)}
                    className="w-full text-left flex items-center"
                  >
                    <div className={`w-6 h-6 rounded-full border-2 mr-4 flex items-center justify-center ${
                      isSelected ? 'border-primary-500 bg-primary-500' : 'border-gray-300'
                    }`}>
                      {isSelected && (
                        <CheckCircle className="h-4 w-4 text-white" />
                      )}
                    </div>
                    <div className="flex-1">
                      <h3 className="font-medium text-gray-900">{candidate.name}</h3>
                      {candidate.description && (
                        <p className="text-sm text-gray-600">{candidate.description}</p>
                      )}
                    </div>
                  </button>
                )}
              </div>
            );
          })}
        </div>

        {/* Selection Summary */}
        {data.election.election_type === 'multiple' && (
          <div className="bg-gray-50 rounded-xl p-4 mb-6">
            <p className="text-sm text-gray-600">
              Selected: {selections.length} / {data.election.max_selections}
            </p>
          </div>
        )}

        {/* Submit Button */}
        <button
          onClick={handleSubmit}
          disabled={submitting || selections.length === 0}
          className="w-full py-4 bg-primary-600 text-white font-medium rounded-xl hover:bg-primary-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
        >
          {submitting ? (
            <span className="flex items-center justify-center">
              <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
              </svg>
              Submitting...
            </span>
          ) : (
            'Submit Vote'
          )}
        </button>

        <p className="text-center text-sm text-gray-500 mt-4">
          Your vote is confidential and cannot be changed after submission.
        </p>
      </div>
    </div>
  );
};

export default VotingPage;
