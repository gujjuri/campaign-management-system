import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import {
  getBroadcast,
  addBroadcastRecipients,
  sendBroadcast,
  getElections,
  getMembers
} from '../services/api';
import {
  ArrowLeft,
  Send,
  Users,
  CheckCircle,
  Clock,
  XCircle,
  Plus,
  X
} from 'lucide-react';

const BroadcastDetail = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const [broadcast, setBroadcast] = useState(null);
  const [loading, setLoading] = useState(true);
  const [sending, setSending] = useState(false);
  const [showAddRecipientsModal, setShowAddRecipientsModal] = useState(false);
  const [elections, setElections] = useState([]);
  const [filterType, setFilterType] = useState('all');
  const [selectedElection, setSelectedElection] = useState('');

  useEffect(() => {
    loadBroadcast();
    loadElections();
  }, [id]);

  const loadBroadcast = async () => {
    try {
      const response = await getBroadcast(id);
      setBroadcast(response.data);
    } catch (error) {
      console.error('Failed to load broadcast:', error);
    } finally {
      setLoading(false);
    }
  };

  const loadElections = async () => {
    try {
      const response = await getElections();
      setElections(response.data);
    } catch (error) {
      console.error('Failed to load elections:', error);
    }
  };

  const handleAddRecipients = async () => {
    try {
      await addBroadcastRecipients(id, {
        filter_type: filterType,
        election_id: selectedElection || undefined
      });
      setShowAddRecipientsModal(false);
      loadBroadcast();
    } catch (error) {
      console.error('Failed to add recipients:', error);
      alert('Failed to add recipients');
    }
  };

  const handleSend = async () => {
    if (!window.confirm('Are you sure you want to send this broadcast? This action cannot be undone.')) {
      return;
    }

    setSending(true);
    try {
      await sendBroadcast(id);
      alert('Broadcast is being sent!');
      loadBroadcast();
    } catch (error) {
      console.error('Failed to send broadcast:', error);
      alert(error.response?.data?.error || 'Failed to send broadcast');
    } finally {
      setSending(false);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary-600"></div>
      </div>
    );
  }

  if (!broadcast) {
    return (
      <div className="text-center py-12">
        <p className="text-gray-500">Broadcast not found</p>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-4">
          <button
            onClick={() => navigate('/broadcasts')}
            className="p-2 hover:bg-gray-100 rounded-lg"
          >
            <ArrowLeft className="h-5 w-5" />
          </button>
          <div>
            <h1 className="text-2xl font-bold text-gray-900">{broadcast.title}</h1>
            <span className={`inline-block mt-1 px-2 py-1 rounded-full text-xs font-medium ${
              broadcast.status === 'completed' ? 'bg-green-100 text-green-700' :
              broadcast.status === 'sending' ? 'bg-blue-100 text-blue-700' :
              broadcast.status === 'draft' ? 'bg-yellow-100 text-yellow-700' :
              'bg-red-100 text-red-700'
            }`}>
              {broadcast.status}
            </span>
          </div>
        </div>
        {broadcast.status === 'draft' && (
          <button
            onClick={handleSend}
            disabled={sending || broadcast.total_recipients === 0}
            className="inline-flex items-center px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 disabled:opacity-50"
          >
            <Send className="h-5 w-5 mr-2" />
            {sending ? 'Sending...' : 'Send Broadcast'}
          </button>
        )}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Message Details */}
        <div className="lg:col-span-2 space-y-6">
          <div className="bg-white rounded-xl shadow-sm p-6">
            <h2 className="text-lg font-semibold text-gray-900 mb-4">Message Content</h2>
            
            <div className="space-y-4">
              <div>
                <label className="text-sm font-medium text-gray-500">Type</label>
                <p className="mt-1 capitalize">{broadcast.message_type}</p>
              </div>

              {broadcast.content && (
                <div>
                  <label className="text-sm font-medium text-gray-500">
                    {broadcast.message_type === 'text' ? 'Message' : 'Caption'}
                  </label>
                  <p className="mt-1 whitespace-pre-wrap bg-gray-50 p-4 rounded-lg">
                    {broadcast.content}
                  </p>
                </div>
              )}

              {broadcast.media_url && (
                <div>
                  <label className="text-sm font-medium text-gray-500">Attachment</label>
                  <div className="mt-1">
                    {broadcast.message_type === 'image' ? (
                      <img
                        src={`http://localhost:3001${broadcast.media_url}`}
                        alt="Broadcast media"
                        className="max-w-sm rounded-lg"
                      />
                    ) : (
                      <a
                        href={`http://localhost:3001${broadcast.media_url}`}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="inline-flex items-center text-primary-600 hover:text-primary-700"
                      >
                        {broadcast.media_filename || 'Download attachment'}
                      </a>
                    )}
                  </div>
                </div>
              )}
            </div>
          </div>

          {/* Recipients */}
          <div className="bg-white rounded-xl shadow-sm">
            <div className="p-6 border-b flex items-center justify-between">
              <h2 className="text-lg font-semibold text-gray-900">
                Recipients ({broadcast.recipients?.length || 0})
              </h2>
              {broadcast.status === 'draft' && (
                <button
                  onClick={() => setShowAddRecipientsModal(true)}
                  className="inline-flex items-center px-3 py-1.5 bg-primary-600 text-white rounded-lg hover:bg-primary-700 text-sm"
                >
                  <Plus className="h-4 w-4 mr-1" />
                  Add Recipients
                </button>
              )}
            </div>
            
            {broadcast.recipients?.length > 0 ? (
              <div className="divide-y max-h-96 overflow-y-auto">
                {broadcast.recipients.map((recipient) => (
                  <div key={recipient.id} className="p-4 flex items-center justify-between">
                    <div>
                      <p className="font-medium text-gray-900">{recipient.full_name}</p>
                      <p className="text-sm text-gray-500">{recipient.phone}</p>
                    </div>
                    <div className="flex items-center">
                      {recipient.status === 'sent' || recipient.status === 'delivered' || recipient.status === 'read' ? (
                        <span className="inline-flex items-center text-green-600 text-sm">
                          <CheckCircle className="h-4 w-4 mr-1" />
                          {recipient.status}
                        </span>
                      ) : recipient.status === 'failed' ? (
                        <span className="inline-flex items-center text-red-600 text-sm">
                          <XCircle className="h-4 w-4 mr-1" />
                          Failed
                        </span>
                      ) : (
                        <span className="inline-flex items-center text-yellow-600 text-sm">
                          <Clock className="h-4 w-4 mr-1" />
                          Pending
                        </span>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="p-8 text-center text-gray-500">
                <Users className="h-12 w-12 mx-auto mb-2 opacity-50" />
                <p>No recipients added yet</p>
              </div>
            )}
          </div>
        </div>

        {/* Stats Sidebar */}
        <div className="space-y-6">
          <div className="bg-white rounded-xl shadow-sm p-6">
            <h2 className="text-lg font-semibold text-gray-900 mb-4">Statistics</h2>
            
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <span className="text-gray-500">Total Recipients</span>
                <span className="font-semibold">{broadcast.stats?.total || 0}</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-gray-500">Sent</span>
                <span className="font-semibold text-blue-600">{broadcast.stats?.sent || 0}</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-gray-500">Delivered</span>
                <span className="font-semibold text-green-600">{broadcast.stats?.delivered || 0}</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-gray-500">Read</span>
                <span className="font-semibold text-green-700">{broadcast.stats?.read || 0}</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-gray-500">Failed</span>
                <span className="font-semibold text-red-600">{broadcast.stats?.failed || 0}</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-gray-500">Pending</span>
                <span className="font-semibold text-yellow-600">{broadcast.stats?.pending || 0}</span>
              </div>
            </div>

            {broadcast.stats?.total > 0 && (
              <div className="mt-4 pt-4 border-t">
                <div className="flex items-center justify-between text-sm mb-2">
                  <span className="text-gray-500">Delivery Rate</span>
                  <span className="font-semibold">
                    {Math.round(((broadcast.stats?.sent || 0) / broadcast.stats.total) * 100)}%
                  </span>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-2">
                  <div
                    className="bg-green-500 h-2 rounded-full"
                    style={{ width: `${((broadcast.stats?.sent || 0) / broadcast.stats.total) * 100}%` }}
                  />
                </div>
              </div>
            )}
          </div>

          <div className="bg-white rounded-xl shadow-sm p-6">
            <h2 className="text-lg font-semibold text-gray-900 mb-4">Details</h2>
            <div className="space-y-3 text-sm">
              <div>
                <span className="text-gray-500">Created</span>
                <p className="font-medium">{new Date(broadcast.created_at).toLocaleString()}</p>
              </div>
              {broadcast.completed_at && (
                <div>
                  <span className="text-gray-500">Completed</span>
                  <p className="font-medium">{new Date(broadcast.completed_at).toLocaleString()}</p>
                </div>
              )}
              {broadcast.created_by_name && (
                <div>
                  <span className="text-gray-500">Created By</span>
                  <p className="font-medium">{broadcast.created_by_name}</p>
                </div>
              )}
              {broadcast.election_title && (
                <div>
                  <span className="text-gray-500">Linked Election</span>
                  <p className="font-medium">{broadcast.election_title}</p>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Add Recipients Modal */}
      {showAddRecipientsModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-xl shadow-xl max-w-md w-full">
            <div className="p-6 border-b flex items-center justify-between">
              <h2 className="text-xl font-semibold">Add Recipients</h2>
              <button onClick={() => setShowAddRecipientsModal(false)}>
                <X className="h-5 w-5" />
              </button>
            </div>
            <div className="p-6 space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Select Recipients
                </label>
                <div className="space-y-2">
                  <label className="flex items-center p-3 bg-gray-50 rounded-lg cursor-pointer hover:bg-gray-100">
                    <input
                      type="radio"
                      name="filterType"
                      value="all"
                      checked={filterType === 'all'}
                      onChange={(e) => setFilterType(e.target.value)}
                      className="h-4 w-4 text-primary-600"
                    />
                    <span className="ml-3">All active members</span>
                  </label>
                  <label className="flex items-center p-3 bg-gray-50 rounded-lg cursor-pointer hover:bg-gray-100">
                    <input
                      type="radio"
                      name="filterType"
                      value="election"
                      checked={filterType === 'election'}
                      onChange={(e) => setFilterType(e.target.value)}
                      className="h-4 w-4 text-primary-600"
                    />
                    <span className="ml-3">Members of specific election</span>
                  </label>
                  <label className="flex items-center p-3 bg-gray-50 rounded-lg cursor-pointer hover:bg-gray-100">
                    <input
                      type="radio"
                      name="filterType"
                      value="not_voted"
                      checked={filterType === 'not_voted'}
                      onChange={(e) => setFilterType(e.target.value)}
                      className="h-4 w-4 text-primary-600"
                    />
                    <span className="ml-3">Members who haven't voted</span>
                  </label>
                </div>
              </div>

              {(filterType === 'election' || filterType === 'not_voted') && (
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Select Election
                  </label>
                  <select
                    value={selectedElection}
                    onChange={(e) => setSelectedElection(e.target.value)}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg"
                    required
                  >
                    <option value="">Choose election...</option>
                    {elections.map((election) => (
                      <option key={election.id} value={election.id}>
                        {election.title}
                      </option>
                    ))}
                  </select>
                </div>
              )}

              <div className="flex justify-end space-x-3 pt-4">
                <button
                  onClick={() => setShowAddRecipientsModal(false)}
                  className="px-4 py-2 text-gray-700 hover:bg-gray-100 rounded-lg"
                >
                  Cancel
                </button>
                <button
                  onClick={handleAddRecipients}
                  disabled={(filterType !== 'all' && !selectedElection)}
                  className="px-4 py-2 bg-primary-600 text-white rounded-lg hover:bg-primary-700 disabled:opacity-50"
                >
                  Add Recipients
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default BroadcastDetail;
