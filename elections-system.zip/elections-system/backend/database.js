const Database = require('better-sqlite3');
const path = require('path');
const bcrypt = require('bcryptjs');

const db = new Database(path.join(__dirname, 'campaign.db'));

// Enable foreign keys
db.pragma('foreign_keys = ON');

// Create tables
db.exec(`
  -- Operators/Users table
  CREATE TABLE IF NOT EXISTS operators (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT UNIQUE NOT NULL,
    email TEXT UNIQUE NOT NULL,
    password TEXT NOT NULL,
    full_name TEXT NOT NULL,
    role TEXT DEFAULT 'operator' CHECK(role IN ('admin', 'operator')),
    is_active INTEGER DEFAULT 1,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );

  -- Campaigns table
  CREATE TABLE IF NOT EXISTS campaigns (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    title TEXT NOT NULL,
    description TEXT,
    status TEXT DEFAULT 'draft' CHECK(status IN ('draft', 'active', 'completed', 'cancelled')),
    start_date DATETIME,
    end_date DATETIME,
    created_by INTEGER REFERENCES operators(id),
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );

  -- Members table (contacts)
  CREATE TABLE IF NOT EXISTS members (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    member_id TEXT UNIQUE,
    full_name TEXT NOT NULL,
    email TEXT,
    phone TEXT NOT NULL,
    whatsapp_number TEXT,
    organization TEXT,
    department TEXT,
    address TEXT,
    city TEXT,
    state TEXT,
    postal_code TEXT,
    country TEXT,
    tags TEXT,
    is_active INTEGER DEFAULT 1,
    metadata TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );

  -- Campaign Members (which members belong to which campaign)
  CREATE TABLE IF NOT EXISTS campaign_members (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    campaign_id INTEGER NOT NULL REFERENCES campaigns(id) ON DELETE CASCADE,
    member_id INTEGER NOT NULL REFERENCES members(id) ON DELETE CASCADE,
    status TEXT DEFAULT 'active',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(campaign_id, member_id)
  );

  -- Broadcast Messages table
  CREATE TABLE IF NOT EXISTS broadcasts (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    title TEXT NOT NULL,
    message_type TEXT NOT NULL CHECK(message_type IN ('text', 'image', 'document', 'template')),
    content TEXT,
    media_url TEXT,
    media_filename TEXT,
    campaign_id INTEGER REFERENCES campaigns(id),
    target_filter TEXT,
    status TEXT DEFAULT 'draft' CHECK(status IN ('draft', 'sending', 'completed', 'failed')),
    total_recipients INTEGER DEFAULT 0,
    sent_count INTEGER DEFAULT 0,
    failed_count INTEGER DEFAULT 0,
    created_by INTEGER REFERENCES operators(id),
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    completed_at DATETIME
  );

  -- Broadcast Recipients table
  CREATE TABLE IF NOT EXISTS broadcast_recipients (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    broadcast_id INTEGER NOT NULL REFERENCES broadcasts(id) ON DELETE CASCADE,
    member_id INTEGER NOT NULL REFERENCES members(id),
    status TEXT DEFAULT 'pending' CHECK(status IN ('pending', 'sent', 'delivered', 'read', 'failed')),
    error_message TEXT,
    sent_at DATETIME,
    delivered_at DATETIME,
    read_at DATETIME
  );

  -- Message Log table (for tracking all WhatsApp messages)
  CREATE TABLE IF NOT EXISTS message_logs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    member_id INTEGER REFERENCES members(id),
    direction TEXT NOT NULL CHECK(direction IN ('outbound', 'inbound')),
    message_type TEXT NOT NULL,
    content TEXT,
    media_url TEXT,
    whatsapp_message_id TEXT,
    status TEXT DEFAULT 'pending',
    error_message TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );

  -- Create indexes for better performance
  CREATE INDEX IF NOT EXISTS idx_members_phone ON members(phone);
  CREATE INDEX IF NOT EXISTS idx_broadcasts_status ON broadcasts(status);
  CREATE INDEX IF NOT EXISTS idx_campaign_members_campaign ON campaign_members(campaign_id);
`);

// Create default admin user if not exists
const adminExists = db.prepare('SELECT id FROM operators WHERE username = ?').get('admin');
if (!adminExists) {
  const hashedPassword = bcrypt.hashSync('admin123', 10);
  db.prepare(`
    INSERT INTO operators (username, email, password, full_name, role)
    VALUES (?, ?, ?, ?, ?)
  `).run('admin', 'admin@campaign.local', hashedPassword, 'System Administrator', 'admin');
  console.log('Default admin user created (username: admin, password: admin123)');
}

module.exports = db;
bound', 'inbound')),
    message_type TEXT NOT NULL,
    content TEXT,
    media_url TEXT,
    whatsapp_message_id TEXT,
    status TEXT DEFAULT 'pending',
    error_message TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );

  -- Create indexes for better performance
  CREATE INDEX IF NOT EXISTS idx_election_members_token ON election_members(voting_token);
  CREATE INDEX IF NOT EXISTS idx_election_members_election ON election_members(election_id);
  CREATE INDEX IF NOT EXISTS idx_votes_election ON votes(election_id);
  CREATE INDEX IF NOT EXISTS idx_members_phone ON members(phone);
  CREATE INDEX IF NOT EXISTS idx_broadcasts_status ON broadcasts(status);
`);

// Create default admin user if not exists
const adminExists = db.prepare('SELECT id FROM operators WHERE username = ?').get('admin');
if (!adminExists) {
  const hashedPassword = bcrypt.hashSync('admin123', 10);
  db.prepare(`
    INSERT INTO operators (username, email, password, full_name, role)
    VALUES (?, ?, ?, ?, ?)
  `).run('admin', 'admin@elections.local', hashedPassword, 'System Administrator', 'admin');
  console.log('Default admin user created (username: admin, password: admin123)');
}

module.exports = db;
