const axios = require('axios');
const FormData = require('form-data');
const fs = require('fs');
const path = require('path');

class EvolutionAPIService {
  constructor() {
    this.baseUrl = process.env.EVOLUTION_API_URL || 'http://localhost:8080';
    this.apiKey = process.env.EVOLUTION_API_KEY || '';
    this.instance = process.env.EVOLUTION_INSTANCE || '';
  }

  getHeaders() {
    return {
      'apikey': this.apiKey,
      'Content-Type': 'application/json'
    };
  }

  formatPhoneNumber(phone) {
    // Remove all non-numeric characters
    let cleaned = phone.replace(/\D/g, '');
    
    // Ensure it has country code (default to removing leading zeros and adding country code if needed)
    if (cleaned.startsWith('0')) {
      cleaned = cleaned.substring(1);
    }
    
    // Return formatted number for WhatsApp (without + sign)
    return cleaned;
  }

  async checkConnection() {
    try {
      const response = await axios.get(
        `${this.baseUrl}/instance/connectionState/${this.instance}`,
        { headers: this.getHeaders() }
      );
      return response.data;
    } catch (error) {
      console.error('Error checking connection:', error.message);
      throw error;
    }
  }

  async sendTextMessage(phone, message) {
    try {
      const formattedPhone = this.formatPhoneNumber(phone);
      const response = await axios.post(
        `${this.baseUrl}/message/sendText/${this.instance}`,
        {
          number: formattedPhone,
          text: message
        },
        { headers: this.getHeaders() }
      );
      return {
        success: true,
        messageId: response.data?.key?.id,
        data: response.data
      };
    } catch (error) {
      console.error('Error sending text message:', error.message);
      return {
        success: false,
        error: error.response?.data?.message || error.message
      };
    }
  }

  async sendImageMessage(phone, imageUrl, caption = '') {
    try {
      const formattedPhone = this.formatPhoneNumber(phone);
      const response = await axios.post(
        `${this.baseUrl}/message/sendMedia/${this.instance}`,
        {
          number: formattedPhone,
          mediatype: 'image',
          media: imageUrl,
          caption: caption
        },
        { headers: this.getHeaders() }
      );
      return {
        success: true,
        messageId: response.data?.key?.id,
        data: response.data
      };
    } catch (error) {
      console.error('Error sending image message:', error.message);
      return {
        success: false,
        error: error.response?.data?.message || error.message
      };
    }
  }

  async sendDocumentMessage(phone, documentUrl, filename, caption = '') {
    try {
      const formattedPhone = this.formatPhoneNumber(phone);
      const response = await axios.post(
        `${this.baseUrl}/message/sendMedia/${this.instance}`,
        {
          number: formattedPhone,
          mediatype: 'document',
          media: documentUrl,
          fileName: filename,
          caption: caption
        },
        { headers: this.getHeaders() }
      );
      return {
        success: true,
        messageId: response.data?.key?.id,
        data: response.data
      };
    } catch (error) {
      console.error('Error sending document message:', error.message);
      return {
        success: false,
        error: error.response?.data?.message || error.message
      };
    }
  }

  async sendMediaFromBase64(phone, base64Data, mediaType, filename, caption = '') {
    try {
      const formattedPhone = this.formatPhoneNumber(phone);
      const response = await axios.post(
        `${this.baseUrl}/message/sendMedia/${this.instance}`,
        {
          number: formattedPhone,
          mediatype: mediaType,
          media: base64Data,
          fileName: filename,
          caption: caption
        },
        { headers: this.getHeaders() }
      );
      return {
        success: true,
        messageId: response.data?.key?.id,
        data: response.data
      };
    } catch (error) {
      console.error('Error sending media from base64:', error.message);
      return {
        success: false,
        error: error.response?.data?.message || error.message
      };
    }
  }

  async sendLocalFile(phone, filePath, caption = '') {
    try {
      const formattedPhone = this.formatPhoneNumber(phone);
      const filename = path.basename(filePath);
      const ext = path.extname(filePath).toLowerCase();
      
      // Read file and convert to base64
      const fileBuffer = fs.readFileSync(filePath);
      const base64Data = fileBuffer.toString('base64');
      
      // Determine media type
      let mediaType = 'document';
      let mimeType = 'application/octet-stream';
      
      if (['.jpg', '.jpeg', '.png', '.gif', '.webp'].includes(ext)) {
        mediaType = 'image';
        mimeType = `image/${ext.substring(1)}`;
      } else if (['.mp4', '.avi', '.mov'].includes(ext)) {
        mediaType = 'video';
        mimeType = `video/${ext.substring(1)}`;
      } else if (['.mp3', '.ogg', '.wav'].includes(ext)) {
        mediaType = 'audio';
        mimeType = `audio/${ext.substring(1)}`;
      } else if (ext === '.pdf') {
        mimeType = 'application/pdf';
      }
      
      const base64WithMime = `data:${mimeType};base64,${base64Data}`;
      
      return await this.sendMediaFromBase64(formattedPhone, base64WithMime, mediaType, filename, caption);
    } catch (error) {
      console.error('Error sending local file:', error.message);
      return {
        success: false,
        error: error.message
      };
    }
  }

  async sendVotingLink(phone, memberName, electionTitle, votingUrl) {
    const message = `🗳️ *Election Notification*\n\nHello ${memberName},\n\nYou are invited to participate in: *${electionTitle}*\n\nPlease cast your vote using the link below:\n${votingUrl}\n\nThis is a secure voting link unique to you. Please do not share it with others.\n\nThank you for your participation!`;
    
    return await this.sendTextMessage(phone, message);
  }

  async sendVotingReminder(phone, memberName, electionTitle, votingUrl, endDate) {
    const message = `⏰ *Voting Reminder*\n\nHello ${memberName},\n\nThis is a reminder that you haven't yet voted in: *${electionTitle}*\n\nVoting ends on: ${endDate}\n\nCast your vote now:\n${votingUrl}\n\nYour vote matters!`;
    
    return await this.sendTextMessage(phone, message);
  }

  async sendVoteConfirmation(phone, memberName, electionTitle) {
    const message = `✅ *Vote Confirmed*\n\nHello ${memberName},\n\nYour vote in *${electionTitle}* has been successfully recorded.\n\nThank you for participating in the election!`;
    
    return await this.sendTextMessage(phone, message);
  }

  async getInstanceInfo() {
    try {
      const response = await axios.get(
        `${this.baseUrl}/instance/fetchInstances`,
        { headers: this.getHeaders() }
      );
      return response.data;
    } catch (error) {
      console.error('Error fetching instances:', error.message);
      throw error;
    }
  }
}

module.exports = new EvolutionAPIService();
