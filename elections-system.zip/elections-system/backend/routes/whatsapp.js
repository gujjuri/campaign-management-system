const express = require('express');
const db = require('../database');
const { authenticateToken } = require('../middleware/auth');
const evolutionAPI = require('../services/evolutionAPI');

const router = express.Router();

// Check Evolution API connection status
router.get('/status', authenticateToken, async (req, res) => {
  try {
    const status = await evolutionAPI.checkConnection();
    res.json(status);
  } catch (error) {
    res.status(500).json({ 
      connected: false, 
      error: error.message 
    });
  }
});

// Get instance info
router.get('/instances', authenticateToken, async (req, res) => {
  try {
    const instances = await evolutionAPI.getInstanceInfo();
    res.json(instances);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Send test message
router.post('/test', authenticateToken, async (req, res) => {
  try {
    const { phone, message } = req.body;

    if (!phone || !message) {
      return res.status(400).json({ error: 'Phone and message are required' });
    }

    const result = await evolutionAPI.sendTextMessage(phone, message);
    res.json(result);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Send message to specific member
router.post('/send/:memberId', authenticateToken, async (req, res) => {
  try {
    const { message, message_type, media_url } = req.body;
    const memberId = req.params.memberId;

    const member = db.prepare('SELECT * FROM members WHERE id = ?').get(memberId);
    if (!member) {
      return res.status(404).json({ error: 'Member not found' });
    }

    const phone = member.whatsapp_number || member.phone;
    let result;

    if (message_type === 'image' && media_url) {
      result = await evolutionAPI.sendImageMessage(phone, media_url, message);
    } else if (message_type === 'document' && media_url) {
      result = await evolutionAPI.sendDocumentMessage(phone, media_url, 'document', message);
    } else {
      result = await evolutionAPI.sendTextMessage(phone, message);
    }

    // Log the message
    db.prepare(`
      INSERT INTO message_logs (member_id, direction, message_type, content, whatsapp_message_id, status)
      VALUES (?, 'outbound', ?, ?, ?, ?)
    `).run(memberId, message_type || 'text', message, result.messageId, result.success ? 'sent' : 'failed');

    res.json(result);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Get message history for a member
router.get('/history/:memberId', authenticateToken, (req, res) => {
  try {
    const messages = db.prepare(`
      SELECT * FROM message_logs
      WHERE member_id = ?
      ORDER BY created_at DESC
      LIMIT 50
    `).all(req.params.memberId);

    res.json(messages);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Update WhatsApp settings
router.put('/settings', authenticateToken, async (req, res) => {
  try {
    const { api_url, api_key, instance } = req.body;

    // Update environment variables (in a real app, you'd save these to a config file or database)
    process.env.EVOLUTION_API_URL = api_url;
    process.env.EVOLUTION_API_KEY = api_key;
    process.env.EVOLUTION_INSTANCE = instance;

    // Reinitialize the service
    evolutionAPI.baseUrl = api_url;
    evolutionAPI.apiKey = api_key;
    evolutionAPI.instance = instance;

    // Test connection
    const status = await evolutionAPI.checkConnection();

    res.json({ 
      message: 'Settings updated',
      connection_status: status
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

module.exports = router;
