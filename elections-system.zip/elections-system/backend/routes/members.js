const express = require('express');
const multer = require('multer');
const csv = require('csv-parser');
const fs = require('fs');
const path = require('path');
const db = require('../database');
const { authenticateToken } = require('../middleware/auth');

const router = express.Router();

// Configure multer for file uploads
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    const uploadDir = path.join(__dirname, '../uploads');
    if (!fs.existsSync(uploadDir)) {
      fs.mkdirSync(uploadDir, { recursive: true });
    }
    cb(null, uploadDir);
  },
  filename: (req, file, cb) => {
    cb(null, `${Date.now()}-${file.originalname}`);
  }
});

const upload = multer({ storage });

// Get all members
router.get('/', authenticateToken, (req, res) => {
  try {
    const { search, page = 1, limit = 50 } = req.query;
    const offset = (page - 1) * limit;

    let query = `
      SELECT * FROM members 
      WHERE is_active = 1
    `;
    let countQuery = 'SELECT COUNT(*) as total FROM members WHERE is_active = 1';
    const params = [];

    if (search) {
      query += ` AND (full_name LIKE ? OR email LIKE ? OR phone LIKE ? OR organization LIKE ? OR address LIKE ? OR city LIKE ?)`;
      countQuery += ` AND (full_name LIKE ? OR email LIKE ? OR phone LIKE ? OR organization LIKE ? OR address LIKE ? OR city LIKE ?)`;
      const searchTerm = `%${search}%`;
      params.push(searchTerm, searchTerm, searchTerm, searchTerm, searchTerm, searchTerm);
    }

    query += ` ORDER BY full_name LIMIT ? OFFSET ?`;

    const members = db.prepare(query).all(...params, parseInt(limit), parseInt(offset));
    const { total } = db.prepare(countQuery).get(...params);

    res.json({
      members,
      pagination: {
        page: parseInt(page),
        limit: parseInt(limit),
        total,
        pages: Math.ceil(total / limit)
      }
    });
  } catch (error) {
    console.error('Get members error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Get single member
router.get('/:id', authenticateToken, (req, res) => {
  try {
    const member = db.prepare('SELECT * FROM members WHERE id = ?').get(req.params.id);
    
    if (!member) {
      return res.status(404).json({ error: 'Member not found' });
    }

    // Get campaign participation
    const campaigns = db.prepare(`
      SELECT c.id, c.title, c.status, cm.created_at as joined_at
      FROM campaign_members cm
      JOIN campaigns c ON cm.campaign_id = c.id
      WHERE cm.member_id = ?
      ORDER BY c.created_at DESC
    `).all(req.params.id);

    // Get message history
    const messages = db.prepare(`
      SELECT * FROM message_logs
      WHERE member_id = ?
      ORDER BY created_at DESC
      LIMIT 20
    `).all(req.params.id);

    res.json({ ...member, campaigns, messages });
  } catch (error) {
    console.error('Get member error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Create member
router.post('/', authenticateToken, (req, res) => {
  try {
    const { 
      member_id, full_name, email, phone, whatsapp_number, 
      organization, department, address, city, state, postal_code, country, 
      tags, metadata 
    } = req.body;

    if (!full_name || !phone) {
      return res.status(400).json({ error: 'Full name and phone are required' });
    }

    const result = db.prepare(`
      INSERT INTO members (member_id, full_name, email, phone, whatsapp_number, organization, department, address, city, state, postal_code, country, tags, metadata)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `).run(
      member_id, full_name, email, phone, whatsapp_number || phone, 
      organization, department, address, city, state, postal_code, country,
      tags, JSON.stringify(metadata || {})
    );

    res.status(201).json({
      id: result.lastInsertRowid,
      member_id,
      full_name,
      email,
      phone,
      whatsapp_number: whatsapp_number || phone,
      organization,
      department,
      address,
      city,
      state,
      postal_code,
      country
    });
  } catch (error) {
    if (error.message.includes('UNIQUE constraint')) {
      return res.status(400).json({ error: 'Member ID already exists' });
    }
    console.error('Create member error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Update member
router.put('/:id', authenticateToken, (req, res) => {
  try {
    const { 
      member_id, full_name, email, phone, whatsapp_number, 
      organization, department, address, city, state, postal_code, country,
      tags, is_active, metadata 
    } = req.body;

    db.prepare(`
      UPDATE members 
      SET member_id = ?, full_name = ?, email = ?, phone = ?, whatsapp_number = ?, 
          organization = ?, department = ?, address = ?, city = ?, state = ?, 
          postal_code = ?, country = ?, tags = ?, is_active = ?, metadata = ?, 
          updated_at = CURRENT_TIMESTAMP
      WHERE id = ?
    `).run(
      member_id, full_name, email, phone, whatsapp_number, 
      organization, department, address, city, state, postal_code, country,
      tags, is_active ? 1 : 0, JSON.stringify(metadata || {}), 
      req.params.id
    );

    res.json({ message: 'Member updated successfully' });
  } catch (error) {
    console.error('Update member error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Delete member (soft delete)
router.delete('/:id', authenticateToken, (req, res) => {
  try {
    db.prepare('UPDATE members SET is_active = 0, updated_at = CURRENT_TIMESTAMP WHERE id = ?')
      .run(req.params.id);
    res.json({ message: 'Member deleted successfully' });
  } catch (error) {
    console.error('Delete member error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Import members from CSV
router.post('/import', authenticateToken, upload.single('file'), async (req, res) => {
  try {
    if (!req.file) {
      return res.status(400).json({ error: 'No file uploaded' });
    }

    const results = [];
    const errors = [];

    const insertStmt = db.prepare(`
      INSERT INTO members (member_id, full_name, email, phone, whatsapp_number, organization, department, address, city, state, postal_code, country)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);

    const updateStmt = db.prepare(`
      UPDATE members 
      SET full_name = ?, email = ?, whatsapp_number = ?, organization = ?, department = ?, 
          address = ?, city = ?, state = ?, postal_code = ?, country = ?, updated_at = CURRENT_TIMESTAMP
      WHERE phone = ?
    `);

    const checkStmt = db.prepare('SELECT id FROM members WHERE phone = ?');

    await new Promise((resolve, reject) => {
      fs.createReadStream(req.file.path)
        .pipe(csv())
        .on('data', (row) => {
          results.push(row);
        })
        .on('end', resolve)
        .on('error', reject);
    });

    let imported = 0;
    let updated = 0;
    let failed = 0;

    const processRows = db.transaction(() => {
      for (const row of results) {
        try {
          // Map CSV columns (flexible column naming)
          const full_name = row.full_name || row.name || row.Name || row.FullName || row['Full Name'];
          const email = row.email || row.Email || row.EMAIL;
          const phone = row.phone || row.Phone || row.PHONE || row.mobile || row.Mobile;
          const whatsapp = row.whatsapp || row.WhatsApp || row.whatsapp_number || row.phone || row.Phone;
          const organization = row.organization || row.Organization || row.company || row.Company;
          const department = row.department || row.Department || row.dept || row.Dept;
          const member_id = row.member_id || row.MemberID || row.id || row.ID;
          const address = row.address || row.Address || row.ADDRESS || row.street || row.Street;
          const city = row.city || row.City || row.CITY;
          const state = row.state || row.State || row.STATE || row.province || row.Province;
          const postal_code = row.postal_code || row.PostalCode || row.zip || row.Zip || row.ZIP || row.pincode || row.Pincode;
          const country = row.country || row.Country || row.COUNTRY;

          if (!full_name || !phone) {
            errors.push({ row, error: 'Missing required fields (full_name, phone)' });
            failed++;
            continue;
          }

          const existing = checkStmt.get(phone);

          if (existing) {
            updateStmt.run(full_name, email, whatsapp || phone, organization, department, address, city, state, postal_code, country, phone);
            updated++;
          } else {
            insertStmt.run(member_id, full_name, email, phone, whatsapp || phone, organization, department, address, city, state, postal_code, country);
            imported++;
          }
        } catch (err) {
          errors.push({ row, error: err.message });
          failed++;
        }
      }
    });

    processRows();

    // Clean up uploaded file
    fs.unlinkSync(req.file.path);

    res.json({
      message: 'Import completed',
      imported,
      updated,
      failed,
      total: results.length,
      errors: errors.slice(0, 10) // Return first 10 errors
    });
  } catch (error) {
    console.error('Import error:', error);
    res.status(500).json({ error: 'Import failed: ' + error.message });
  }
});

// Export members to CSV
router.get('/export/csv', authenticateToken, (req, res) => {
  try {
    const members = db.prepare(`
      SELECT member_id, full_name, email, phone, whatsapp_number, organization, department, address, city, state, postal_code, country
      FROM members WHERE is_active = 1
      ORDER BY full_name
    `).all();

    const csvHeader = 'member_id,full_name,email,phone,whatsapp_number,organization,department,address,city,state,postal_code,country\n';
    const csvRows = members.map(m => 
      `"${m.member_id || ''}","${m.full_name}","${m.email || ''}","${m.phone}","${m.whatsapp_number || ''}","${m.organization || ''}","${m.department || ''}","${m.address || ''}","${m.city || ''}","${m.state || ''}","${m.postal_code || ''}","${m.country || ''}"`
    ).join('\n');

    res.setHeader('Content-Type', 'text/csv');
    res.setHeader('Content-Disposition', 'attachment; filename=members.csv');
    res.send(csvHeader + csvRows);
  } catch (error) {
    console.error('Export error:', error);
    res.status(500).json({ error: 'Export failed' });
  }
});

// Get member statistics
router.get('/stats/overview', authenticateToken, (req, res) => {
  try {
    const stats = db.prepare(`
      SELECT 
        COUNT(*) as total_members,
        COUNT(CASE WHEN is_active = 1 THEN 1 END) as active_members,
        COUNT(DISTINCT organization) as organizations,
        COUNT(DISTINCT city) as cities
      FROM members
    `).get();

    const byOrganization = db.prepare(`
      SELECT organization, COUNT(*) as count
      FROM members
      WHERE is_active = 1 AND organization IS NOT NULL AND organization != ''
      GROUP BY organization
      ORDER BY count DESC
      LIMIT 10
    `).all();

    const byCity = db.prepare(`
      SELECT city, COUNT(*) as count
      FROM members
      WHERE is_active = 1 AND city IS NOT NULL AND city != ''
      GROUP BY city
      ORDER BY count DESC
      LIMIT 10
    `).all();

    res.json({ stats, byOrganization, byCity });
  } catch (error) {
    console.error('Get stats error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

module.exports = router;
