const express = require('express');
const multer = require('multer');
const path = require('path');
const fs = require('fs');
const db = require('../database');
const { authenticateToken } = require('../middleware/auth');
const evolutionAPI = require('../services/evolutionAPI');

const router = express.Router();

// Configure multer for media uploads
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    const uploadDir = path.join(__dirname, '../uploads/broadcasts');
    if (!fs.existsSync(uploadDir)) {
      fs.mkdirSync(uploadDir, { recursive: true });
    }
    cb(null, uploadDir);
  },
  filename: (req, file, cb) => {
    const uniqueName = `${Date.now()}-${Math.random().toString(36).substring(7)}${path.extname(file.originalname)}`;
    cb(null, uniqueName);
  }
});

const upload = multer({
  storage,
  limits: { fileSize: 16 * 1024 * 1024 }, // 16MB limit
  fileFilter: (req, file, cb) => {
    const allowedTypes = /jpeg|jpg|png|gif|pdf|doc|docx|xls|xlsx|mp4|mp3/;
    const extname = allowedTypes.test(path.extname(file.originalname).toLowerCase());
    if (extname) {
      return cb(null, true);
    }
    cb(new Error('Invalid file type'));
  }
});

// Get all broadcasts
router.get('/', authenticateToken, (req, res) => {
  try {
    const { status, election_id } = req.query;
    
    let query = `
      SELECT b.*, o.full_name as created_by_name, e.title as election_title
      FROM broadcasts b
      LEFT JOIN operators o ON b.created_by = o.id
      LEFT JOIN elections e ON b.election_id = e.id
      WHERE 1=1
    `;
    const params = [];

    if (status) {
      query += ' AND b.status = ?';
      params.push(status);
    }
    if (election_id) {
      query += ' AND b.election_id = ?';
      params.push(election_id);
    }

    query += ' ORDER BY b.created_at DESC';

    const broadcasts = db.prepare(query).all(...params);
    res.json(broadcasts);
  } catch (error) {
    console.error('Get broadcasts error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Get single broadcast with recipients
router.get('/:id', authenticateToken, (req, res) => {
  try {
    const broadcast = db.prepare(`
      SELECT b.*, o.full_name as created_by_name, e.title as election_title
      FROM broadcasts b
      LEFT JOIN operators o ON b.created_by = o.id
      LEFT JOIN elections e ON b.election_id = e.id
      WHERE b.id = ?
    `).get(req.params.id);

    if (!broadcast) {
      return res.status(404).json({ error: 'Broadcast not found' });
    }

    const recipients = db.prepare(`
      SELECT br.*, m.full_name, m.phone, m.organization
      FROM broadcast_recipients br
      JOIN members m ON br.member_id = m.id
      WHERE br.broadcast_id = ?
      ORDER BY br.status, m.full_name
    `).all(req.params.id);

    const stats = db.prepare(`
      SELECT 
        COUNT(*) as total,
        SUM(CASE WHEN status = 'sent' THEN 1 ELSE 0 END) as sent,
        SUM(CASE WHEN status = 'delivered' THEN 1 ELSE 0 END) as delivered,
        SUM(CASE WHEN status = 'read' THEN 1 ELSE 0 END) as read,
        SUM(CASE WHEN status = 'failed' THEN 1 ELSE 0 END) as failed,
        SUM(CASE WHEN status = 'pending' THEN 1 ELSE 0 END) as pending
      FROM broadcast_recipients
      WHERE broadcast_id = ?
    `).get(req.params.id);

    res.json({ ...broadcast, recipients, stats });
  } catch (error) {
    console.error('Get broadcast error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Create broadcast (text message)
router.post('/', authenticateToken, (req, res) => {
  try {
    const { title, content, election_id, target_filter } = req.body;

    if (!title || !content) {
      return res.status(400).json({ error: 'Title and content are required' });
    }

    const result = db.prepare(`
      INSERT INTO broadcasts (title, message_type, content, election_id, target_filter, created_by)
      VALUES (?, 'text', ?, ?, ?, ?)
    `).run(title, content, election_id || null, target_filter || null, req.user.id);

    res.status(201).json({
      id: result.lastInsertRowid,
      title,
      message_type: 'text',
      content,
      status: 'draft'
    });
  } catch (error) {
    console.error('Create broadcast error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Create broadcast with media (image or document)
router.post('/media', authenticateToken, upload.single('media'), (req, res) => {
  try {
    const { title, caption, message_type, election_id, target_filter } = req.body;

    if (!title || !req.file) {
      return res.status(400).json({ error: 'Title and media file are required' });
    }

    const mediaPath = `/uploads/broadcasts/${req.file.filename}`;
    const mediaType = message_type || (req.file.mimetype.startsWith('image/') ? 'image' : 'document');

    const result = db.prepare(`
      INSERT INTO broadcasts (title, message_type, content, media_url, media_filename, election_id, target_filter, created_by)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    `).run(title, mediaType, caption || '', mediaPath, req.file.originalname, election_id || null, target_filter || null, req.user.id);

    res.status(201).json({
      id: result.lastInsertRowid,
      title,
      message_type: mediaType,
      content: caption,
      media_url: mediaPath,
      media_filename: req.file.originalname,
      status: 'draft'
    });
  } catch (error) {
    console.error('Create media broadcast error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Update broadcast
router.put('/:id', authenticateToken, (req, res) => {
  try {
    const { title, content, election_id, target_filter } = req.body;
    
    const broadcast = db.prepare('SELECT status FROM broadcasts WHERE id = ?').get(req.params.id);
    if (broadcast && broadcast.status !== 'draft') {
      return res.status(400).json({ error: 'Can only edit draft broadcasts' });
    }

    db.prepare(`
      UPDATE broadcasts 
      SET title = ?, content = ?, election_id = ?, target_filter = ?
      WHERE id = ?
    `).run(title, content, election_id, target_filter, req.params.id);

    res.json({ message: 'Broadcast updated successfully' });
  } catch (error) {
    console.error('Update broadcast error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Delete broadcast
router.delete('/:id', authenticateToken, (req, res) => {
  try {
    const broadcast = db.prepare('SELECT status, media_url FROM broadcasts WHERE id = ?').get(req.params.id);
    
    if (broadcast && broadcast.status === 'sending') {
      return res.status(400).json({ error: 'Cannot delete broadcast while sending' });
    }

    // Delete media file if exists
    if (broadcast && broadcast.media_url) {
      const filePath = path.join(__dirname, '..', broadcast.media_url);
      if (fs.existsSync(filePath)) {
        fs.unlinkSync(filePath);
      }
    }

    db.prepare('DELETE FROM broadcasts WHERE id = ?').run(req.params.id);
    res.json({ message: 'Broadcast deleted successfully' });
  } catch (error) {
    console.error('Delete broadcast error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Add recipients to broadcast
router.post('/:id/recipients', authenticateToken, (req, res) => {
  try {
    const { member_ids, filter_type } = req.body;
    const broadcastId = req.params.id;

    let membersToAdd = [];

    if (filter_type === 'all') {
      membersToAdd = db.prepare('SELECT id FROM members WHERE is_active = 1').all();
    } else if (filter_type === 'election' && req.body.election_id) {
      membersToAdd = db.prepare(`
        SELECT m.id FROM members m
        JOIN election_members em ON m.id = em.member_id
        WHERE em.election_id = ? AND m.is_active = 1
      `).all(req.body.election_id);
    } else if (filter_type === 'not_voted' && req.body.election_id) {
      membersToAdd = db.prepare(`
        SELECT m.id FROM members m
        JOIN election_members em ON m.id = em.member_id
        WHERE em.election_id = ? AND em.has_voted = 0 AND m.is_active = 1
      `).all(req.body.election_id);
    } else if (member_ids && member_ids.length > 0) {
      membersToAdd = member_ids.map(id => ({ id }));
    }

    const insertStmt = db.prepare(`
      INSERT OR IGNORE INTO broadcast_recipients (broadcast_id, member_id)
      VALUES (?, ?)
    `);

    const insertMany = db.transaction((members) => {
      for (const member of members) {
        insertStmt.run(broadcastId, member.id);
      }
    });

    insertMany(membersToAdd);

    // Update total recipients count
    const count = db.prepare('SELECT COUNT(*) as count FROM broadcast_recipients WHERE broadcast_id = ?')
      .get(broadcastId);
    db.prepare('UPDATE broadcasts SET total_recipients = ? WHERE id = ?')
      .run(count.count, broadcastId);

    res.json({ 
      message: 'Recipients added successfully',
      count: membersToAdd.length
    });
  } catch (error) {
    console.error('Add recipients error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Remove recipient from broadcast
router.delete('/:id/recipients/:recipientId', authenticateToken, (req, res) => {
  try {
    db.prepare('DELETE FROM broadcast_recipients WHERE broadcast_id = ? AND id = ?')
      .run(req.params.id, req.params.recipientId);
    
    // Update count
    const count = db.prepare('SELECT COUNT(*) as count FROM broadcast_recipients WHERE broadcast_id = ?')
      .get(req.params.id);
    db.prepare('UPDATE broadcasts SET total_recipients = ? WHERE id = ?')
      .run(count.count, req.params.id);

    res.json({ message: 'Recipient removed' });
  } catch (error) {
    console.error('Remove recipient error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Send broadcast
router.post('/:id/send', authenticateToken, async (req, res) => {
  try {
    const broadcastId = req.params.id;
    
    const broadcast = db.prepare('SELECT * FROM broadcasts WHERE id = ?').get(broadcastId);
    if (!broadcast) {
      return res.status(404).json({ error: 'Broadcast not found' });
    }

    if (broadcast.status !== 'draft') {
      return res.status(400).json({ error: 'Broadcast has already been sent or is sending' });
    }

    const recipients = db.prepare(`
      SELECT br.id as recipient_id, m.id as member_id, m.full_name, m.phone, m.whatsapp_number
      FROM broadcast_recipients br
      JOIN members m ON br.member_id = m.id
      WHERE br.broadcast_id = ? AND br.status = 'pending'
    `).all(broadcastId);

    if (recipients.length === 0) {
      return res.status(400).json({ error: 'No recipients to send to' });
    }

    // Update status to sending
    db.prepare('UPDATE broadcasts SET status = ? WHERE id = ?').run('sending', broadcastId);

    // Send response immediately
    res.json({ 
      message: 'Broadcast started',
      total_recipients: recipients.length
    });

    // Process sending in background
    let sentCount = 0;
    let failedCount = 0;

    for (const recipient of recipients) {
      const phone = recipient.whatsapp_number || recipient.phone;
      let result;

      try {
        // Personalize message with member name
        const personalizedContent = broadcast.content
          ? broadcast.content.replace(/\{name\}/gi, recipient.full_name)
          : '';

        if (broadcast.message_type === 'text') {
          result = await evolutionAPI.sendTextMessage(phone, personalizedContent);
        } else if (broadcast.message_type === 'image') {
          const filePath = path.join(__dirname, '..', broadcast.media_url);
          result = await evolutionAPI.sendLocalFile(phone, filePath, personalizedContent);
        } else if (broadcast.message_type === 'document') {
          const filePath = path.join(__dirname, '..', broadcast.media_url);
          result = await evolutionAPI.sendLocalFile(phone, filePath, personalizedContent);
        }

        if (result && result.success) {
          db.prepare(`
            UPDATE broadcast_recipients 
            SET status = 'sent', sent_at = CURRENT_TIMESTAMP
            WHERE id = ?
          `).run(recipient.recipient_id);
          sentCount++;

          // Log message
          db.prepare(`
            INSERT INTO message_logs (member_id, direction, message_type, content, whatsapp_message_id, status)
            VALUES (?, 'outbound', ?, ?, ?, 'sent')
          `).run(recipient.member_id, broadcast.message_type, personalizedContent, result.messageId);
        } else {
          db.prepare(`
            UPDATE broadcast_recipients 
            SET status = 'failed', error_message = ?
            WHERE id = ?
          `).run(result?.error || 'Unknown error', recipient.recipient_id);
          failedCount++;
        }
      } catch (err) {
        db.prepare(`
          UPDATE broadcast_recipients 
          SET status = 'failed', error_message = ?
          WHERE id = ?
        `).run(err.message, recipient.recipient_id);
        failedCount++;
      }

      // Delay between messages to avoid rate limiting
      await new Promise(resolve => setTimeout(resolve, 1000));
    }

    // Update broadcast status
    db.prepare(`
      UPDATE broadcasts 
      SET status = 'completed', sent_count = ?, failed_count = ?, completed_at = CURRENT_TIMESTAMP
      WHERE id = ?
    `).run(sentCount, failedCount, broadcastId);

  } catch (error) {
    console.error('Send broadcast error:', error);
    db.prepare('UPDATE broadcasts SET status = ? WHERE id = ?').run('failed', req.params.id);
  }
});

// Get broadcast statistics
router.get('/stats/overview', authenticateToken, (req, res) => {
  try {
    const stats = db.prepare(`
      SELECT 
        COUNT(*) as total_broadcasts,
        SUM(CASE WHEN status = 'completed' THEN 1 ELSE 0 END) as completed,
        SUM(CASE WHEN status = 'draft' THEN 1 ELSE 0 END) as drafts,
        SUM(sent_count) as total_sent,
        SUM(failed_count) as total_failed
      FROM broadcasts
    `).get();

    const recent = db.prepare(`
      SELECT id, title, message_type, status, sent_count, total_recipients, created_at
      FROM broadcasts
      ORDER BY created_at DESC
      LIMIT 5
    `).all();

    res.json({ stats, recent });
  } catch (error) {
    console.error('Get broadcast stats error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

module.exports = router;
