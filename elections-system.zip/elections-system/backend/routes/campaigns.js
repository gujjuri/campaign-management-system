const express = require('express');
const db = require('../database');
const { authenticateToken } = require('../middleware/auth');

const router = express.Router();

// Get all campaigns
router.get('/', authenticateToken, (req, res) => {
  try {
    const campaigns = db.prepare(`
      SELECT c.*, o.full_name as created_by_name,
        (SELECT COUNT(*) FROM campaign_members WHERE campaign_id = c.id) as total_members,
        (SELECT COUNT(*) FROM broadcasts WHERE campaign_id = c.id) as broadcast_count
      FROM campaigns c
      LEFT JOIN operators o ON c.created_by = o.id
      ORDER BY c.created_at DESC
    `).all();

    res.json(campaigns);
  } catch (error) {
    console.error('Get campaigns error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Get single campaign
router.get('/:id', authenticateToken, (req, res) => {
  try {
    const campaign = db.prepare(`
      SELECT c.*, o.full_name as created_by_name
      FROM campaigns c
      LEFT JOIN operators o ON c.created_by = o.id
      WHERE c.id = ?
    `).get(req.params.id);

    if (!campaign) {
      return res.status(404).json({ error: 'Campaign not found' });
    }

    // Get member stats
    const stats = db.prepare(`
      SELECT COUNT(*) as total_members
      FROM campaign_members
      WHERE campaign_id = ?
    `).get(req.params.id);

    // Get broadcast stats
    const broadcastStats = db.prepare(`
      SELECT 
        COUNT(*) as total_broadcasts,
        SUM(sent_count) as total_sent,
        SUM(failed_count) as total_failed
      FROM broadcasts
      WHERE campaign_id = ?
    `).get(req.params.id);

    res.json({
      ...campaign,
      stats,
      broadcastStats
    });
  } catch (error) {
    console.error('Get campaign error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Create campaign
router.post('/', authenticateToken, (req, res) => {
  try {
    const { title, description, start_date, end_date } = req.body;

    if (!title) {
      return res.status(400).json({ error: 'Title is required' });
    }

    const result = db.prepare(`
      INSERT INTO campaigns (title, description, start_date, end_date, created_by)
      VALUES (?, ?, ?, ?, ?)
    `).run(title, description, start_date, end_date, req.user.id);

    res.status(201).json({
      id: result.lastInsertRowid,
      title,
      description,
      start_date,
      end_date,
      status: 'draft'
    });
  } catch (error) {
    console.error('Create campaign error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Update campaign
router.put('/:id', authenticateToken, (req, res) => {
  try {
    const { title, description, start_date, end_date, status } = req.body;

    db.prepare(`
      UPDATE campaigns 
      SET title = ?, description = ?, start_date = ?, end_date = ?, status = ?, updated_at = CURRENT_TIMESTAMP
      WHERE id = ?
    `).run(title, description, start_date, end_date, status, req.params.id);

    res.json({ message: 'Campaign updated successfully' });
  } catch (error) {
    console.error('Update campaign error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Delete campaign
router.delete('/:id', authenticateToken, (req, res) => {
  try {
    db.prepare('DELETE FROM campaigns WHERE id = ?').run(req.params.id);
    res.json({ message: 'Campaign deleted successfully' });
  } catch (error) {
    console.error('Delete campaign error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Add members to campaign
router.post('/:id/members', authenticateToken, (req, res) => {
  try {
    const { member_ids } = req.body;
    const campaignId = req.params.id;

    const insertStmt = db.prepare(`
      INSERT OR IGNORE INTO campaign_members (campaign_id, member_id)
      VALUES (?, ?)
    `);

    const insertMany = db.transaction((memberIds) => {
      for (const memberId of memberIds) {
        insertStmt.run(campaignId, memberId);
      }
    });

    insertMany(member_ids);

    res.status(201).json({ message: 'Members added to campaign successfully' });
  } catch (error) {
    console.error('Add members to campaign error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Get campaign members
router.get('/:id/members', authenticateToken, (req, res) => {
  try {
    const members = db.prepare(`
      SELECT cm.*, m.full_name, m.email, m.phone, m.organization, m.department, m.whatsapp_number
      FROM campaign_members cm
      JOIN members m ON cm.member_id = m.id
      WHERE cm.campaign_id = ?
      ORDER BY m.full_name
    `).all(req.params.id);

    res.json(members);
  } catch (error) {
    console.error('Get campaign members error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Remove member from campaign
router.delete('/:id/members/:memberId', authenticateToken, (req, res) => {
  try {
    db.prepare('DELETE FROM campaign_members WHERE campaign_id = ? AND member_id = ?')
      .run(req.params.id, req.params.memberId);
    res.json({ message: 'Member removed from campaign' });
  } catch (error) {
    console.error('Remove member from campaign error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Add all members to campaign
router.post('/:id/members/all', authenticateToken, (req, res) => {
  try {
    const campaignId = req.params.id;
    
    const allMembers = db.prepare('SELECT id FROM members WHERE is_active = 1').all();
    
    const insertStmt = db.prepare(`
      INSERT OR IGNORE INTO campaign_members (campaign_id, member_id)
      VALUES (?, ?)
    `);

    const insertMany = db.transaction((members) => {
      for (const member of members) {
        insertStmt.run(campaignId, member.id);
      }
    });

    insertMany(allMembers);

    res.status(201).json({ 
      message: 'All members added to campaign',
      count: allMembers.length
    });
  } catch (error) {
    console.error('Add all members error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

module.exports = router;
