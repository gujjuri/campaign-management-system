const express = require('express');
const db = require('../database');
const evolutionAPI = require('../services/evolutionAPI');

const router = express.Router();

// Get voting page data (public - no auth required)
router.get('/:token', (req, res) => {
  try {
    const { token } = req.params;

    const electionMember = db.prepare(`
      SELECT em.*, e.*, m.full_name as member_name
      FROM election_members em
      JOIN elections e ON em.election_id = e.id
      JOIN members m ON em.member_id = m.id
      WHERE em.voting_token = ?
    `).get(token);

    if (!electionMember) {
      return res.status(404).json({ error: 'Invalid voting link' });
    }

    if (electionMember.has_voted) {
      return res.status(400).json({ 
        error: 'You have already voted in this election',
        voted_at: electionMember.voted_at
      });
    }

    const now = new Date();
    const startDate = new Date(electionMember.start_date);
    const endDate = new Date(electionMember.end_date);

    if (now < startDate) {
      return res.status(400).json({ 
        error: 'Voting has not started yet',
        starts_at: electionMember.start_date
      });
    }

    if (now > endDate) {
      return res.status(400).json({ 
        error: 'Voting has ended',
        ended_at: electionMember.end_date
      });
    }

    if (electionMember.status !== 'active') {
      return res.status(400).json({ error: 'This election is not currently active' });
    }

    // Get candidates
    const candidates = db.prepare(`
      SELECT id, name, description, photo_url, position
      FROM candidates
      WHERE election_id = ?
      ORDER BY position
    `).all(electionMember.election_id);

    res.json({
      election: {
        id: electionMember.election_id,
        title: electionMember.title,
        description: electionMember.description,
        election_type: electionMember.election_type,
        max_selections: electionMember.max_selections,
        end_date: electionMember.end_date
      },
      member_name: electionMember.member_name,
      candidates
    });
  } catch (error) {
    console.error('Get voting page error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Submit vote (public - no auth required)
router.post('/:token', async (req, res) => {
  try {
    const { token } = req.params;
    const { selections } = req.body; // Array of candidate IDs or vote values

    const electionMember = db.prepare(`
      SELECT em.*, e.*, m.full_name as member_name, m.phone, m.whatsapp_number
      FROM election_members em
      JOIN elections e ON em.election_id = e.id
      JOIN members m ON em.member_id = m.id
      WHERE em.voting_token = ?
    `).get(token);

    if (!electionMember) {
      return res.status(404).json({ error: 'Invalid voting link' });
    }

    if (electionMember.has_voted) {
      return res.status(400).json({ error: 'You have already voted' });
    }

    const now = new Date();
    const startDate = new Date(electionMember.start_date);
    const endDate = new Date(electionMember.end_date);

    if (now < startDate || now > endDate) {
      return res.status(400).json({ error: 'Voting is not currently open' });
    }

    if (electionMember.status !== 'active') {
      return res.status(400).json({ error: 'This election is not active' });
    }

    // Validate selections based on election type
    if (!selections || !Array.isArray(selections) || selections.length === 0) {
      return res.status(400).json({ error: 'Please make a selection' });
    }

    if (electionMember.election_type === 'single' && selections.length > 1) {
      return res.status(400).json({ error: 'You can only select one candidate' });
    }

    if (electionMember.election_type === 'multiple' && selections.length > electionMember.max_selections) {
      return res.status(400).json({ 
        error: `You can only select up to ${electionMember.max_selections} candidates` 
      });
    }

    // Record votes
    const insertVote = db.prepare(`
      INSERT INTO votes (election_id, election_member_id, candidate_id, vote_value, rank_position)
      VALUES (?, ?, ?, ?, ?)
    `);

    const recordVotes = db.transaction(() => {
      for (let i = 0; i < selections.length; i++) {
        const selection = selections[i];
        
        if (electionMember.election_type === 'yesno') {
          // For yes/no voting, selection is { candidate_id, value: 'yes'|'no'|'abstain' }
          insertVote.run(
            electionMember.election_id,
            electionMember.id,
            selection.candidate_id,
            selection.value,
            null
          );
        } else if (electionMember.election_type === 'ranked') {
          // For ranked voting, selections are in order of preference
          insertVote.run(
            electionMember.election_id,
            electionMember.id,
            selection,
            null,
            i + 1
          );
        } else {
          // For single/multiple selection
          insertVote.run(
            electionMember.election_id,
            electionMember.id,
            selection,
            null,
            null
          );
        }
      }

      // Mark as voted
      db.prepare(`
        UPDATE election_members 
        SET has_voted = 1, voted_at = CURRENT_TIMESTAMP
        WHERE id = ?
      `).run(electionMember.id);
    });

    recordVotes();

    // Send confirmation via WhatsApp
    const phone = electionMember.whatsapp_number || electionMember.phone;
    try {
      await evolutionAPI.sendVoteConfirmation(
        phone,
        electionMember.member_name,
        electionMember.title
      );
    } catch (err) {
      console.error('Failed to send vote confirmation:', err);
      // Don't fail the vote if WhatsApp fails
    }

    res.json({ 
      message: 'Your vote has been recorded successfully',
      voted_at: new Date().toISOString()
    });
  } catch (error) {
    console.error('Submit vote error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

module.exports = router;
