const express = require('express');
const { v4: uuidv4 } = require('uuid');
const db = require('../database');
const { authenticateToken } = require('../middleware/auth');
const evolutionAPI = require('../services/evolutionAPI');

const router = express.Router();

// Get all elections
router.get('/', authenticateToken, (req, res) => {
  try {
    const elections = db.prepare(`
      SELECT e.*, o.full_name as created_by_name,
        (SELECT COUNT(*) FROM election_members WHERE election_id = e.id) as total_members,
        (SELECT COUNT(*) FROM election_members WHERE election_id = e.id AND has_voted = 1) as voted_count,
        (SELECT COUNT(*) FROM candidates WHERE election_id = e.id) as candidate_count
      FROM elections e
      LEFT JOIN operators o ON e.created_by = o.id
      ORDER BY e.created_at DESC
    `).all();

    res.json(elections);
  } catch (error) {
    console.error('Get elections error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Get single election
router.get('/:id', authenticateToken, (req, res) => {
  try {
    const election = db.prepare(`
      SELECT e.*, o.full_name as created_by_name
      FROM elections e
      LEFT JOIN operators o ON e.created_by = o.id
      WHERE e.id = ?
    `).get(req.params.id);

    if (!election) {
      return res.status(404).json({ error: 'Election not found' });
    }

    // Get candidates
    const candidates = db.prepare(`
      SELECT c.*, 
        (SELECT COUNT(*) FROM votes WHERE candidate_id = c.id) as vote_count
      FROM candidates c
      WHERE c.election_id = ?
      ORDER BY c.position
    `).all(req.params.id);

    // Get member stats
    const stats = db.prepare(`
      SELECT 
        COUNT(*) as total_members,
        SUM(CASE WHEN has_voted = 1 THEN 1 ELSE 0 END) as voted_count
      FROM election_members
      WHERE election_id = ?
    `).get(req.params.id);

    res.json({
      ...election,
      candidates,
      stats
    });
  } catch (error) {
    console.error('Get election error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Create election
router.post('/', authenticateToken, (req, res) => {
  try {
    const { title, description, election_type, max_selections, start_date, end_date } = req.body;

    if (!title || !start_date || !end_date) {
      return res.status(400).json({ error: 'Title, start date, and end date are required' });
    }

    const result = db.prepare(`
      INSERT INTO elections (title, description, election_type, max_selections, start_date, end_date, created_by)
      VALUES (?, ?, ?, ?, ?, ?, ?)
    `).run(title, description, election_type || 'single', max_selections || 1, start_date, end_date, req.user.id);

    res.status(201).json({
      id: result.lastInsertRowid,
      title,
      description,
      election_type: election_type || 'single',
      max_selections: max_selections || 1,
      start_date,
      end_date,
      status: 'draft'
    });
  } catch (error) {
    console.error('Create election error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Update election
router.put('/:id', authenticateToken, (req, res) => {
  try {
    const { title, description, election_type, max_selections, start_date, end_date, status } = req.body;

    db.prepare(`
      UPDATE elections 
      SET title = ?, description = ?, election_type = ?, max_selections = ?, 
          start_date = ?, end_date = ?, status = ?, updated_at = CURRENT_TIMESTAMP
      WHERE id = ?
    `).run(title, description, election_type, max_selections, start_date, end_date, status, req.params.id);

    res.json({ message: 'Election updated successfully' });
  } catch (error) {
    console.error('Update election error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Delete election
router.delete('/:id', authenticateToken, (req, res) => {
  try {
    db.prepare('DELETE FROM elections WHERE id = ?').run(req.params.id);
    res.json({ message: 'Election deleted successfully' });
  } catch (error) {
    console.error('Delete election error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Add candidates to election
router.post('/:id/candidates', authenticateToken, (req, res) => {
  try {
    const { candidates } = req.body;
    const electionId = req.params.id;

    const insertStmt = db.prepare(`
      INSERT INTO candidates (election_id, name, description, photo_url, position)
      VALUES (?, ?, ?, ?, ?)
    `);

    const insertMany = db.transaction((candidates) => {
      for (const [index, candidate] of candidates.entries()) {
        insertStmt.run(electionId, candidate.name, candidate.description, candidate.photo_url, index);
      }
    });

    insertMany(candidates);

    res.status(201).json({ message: 'Candidates added successfully' });
  } catch (error) {
    console.error('Add candidates error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Update candidate
router.put('/:id/candidates/:candidateId', authenticateToken, (req, res) => {
  try {
    const { name, description, photo_url, position } = req.body;

    db.prepare(`
      UPDATE candidates SET name = ?, description = ?, photo_url = ?, position = ?
      WHERE id = ? AND election_id = ?
    `).run(name, description, photo_url, position, req.params.candidateId, req.params.id);

    res.json({ message: 'Candidate updated successfully' });
  } catch (error) {
    console.error('Update candidate error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Delete candidate
router.delete('/:id/candidates/:candidateId', authenticateToken, (req, res) => {
  try {
    db.prepare('DELETE FROM candidates WHERE id = ? AND election_id = ?')
      .run(req.params.candidateId, req.params.id);
    res.json({ message: 'Candidate deleted successfully' });
  } catch (error) {
    console.error('Delete candidate error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Add members to election
router.post('/:id/members', authenticateToken, (req, res) => {
  try {
    const { member_ids } = req.body;
    const electionId = req.params.id;

    const insertStmt = db.prepare(`
      INSERT OR IGNORE INTO election_members (election_id, member_id, voting_token)
      VALUES (?, ?, ?)
    `);

    const insertMany = db.transaction((memberIds) => {
      for (const memberId of memberIds) {
        const token = uuidv4();
        insertStmt.run(electionId, memberId, token);
      }
    });

    insertMany(member_ids);

    res.status(201).json({ message: 'Members added to election successfully' });
  } catch (error) {
    console.error('Add members to election error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Get election members
router.get('/:id/members', authenticateToken, (req, res) => {
  try {
    const members = db.prepare(`
      SELECT em.*, m.full_name, m.email, m.phone, m.organization, m.department
      FROM election_members em
      JOIN members m ON em.member_id = m.id
      WHERE em.election_id = ?
      ORDER BY m.full_name
    `).all(req.params.id);

    res.json(members);
  } catch (error) {
    console.error('Get election members error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Remove member from election
router.delete('/:id/members/:memberId', authenticateToken, (req, res) => {
  try {
    db.prepare('DELETE FROM election_members WHERE election_id = ? AND member_id = ?')
      .run(req.params.id, req.params.memberId);
    res.json({ message: 'Member removed from election' });
  } catch (error) {
    console.error('Remove member from election error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Send voting links to all members
router.post('/:id/send-voting-links', authenticateToken, async (req, res) => {
  try {
    const electionId = req.params.id;
    const frontendUrl = process.env.FRONTEND_URL || 'http://localhost:3000';

    const election = db.prepare('SELECT * FROM elections WHERE id = ?').get(electionId);
    if (!election) {
      return res.status(404).json({ error: 'Election not found' });
    }

    const members = db.prepare(`
      SELECT em.*, m.full_name, m.phone, m.whatsapp_number
      FROM election_members em
      JOIN members m ON em.member_id = m.id
      WHERE em.election_id = ? AND em.has_voted = 0
    `).all(electionId);

    let sentCount = 0;
    let failedCount = 0;

    for (const member of members) {
      const phone = member.whatsapp_number || member.phone;
      const votingUrl = `${frontendUrl}/vote/${member.voting_token}`;

      const result = await evolutionAPI.sendVotingLink(
        phone,
        member.full_name,
        election.title,
        votingUrl
      );

      if (result.success) {
        sentCount++;
      } else {
        failedCount++;
      }

      // Small delay to avoid rate limiting
      await new Promise(resolve => setTimeout(resolve, 500));
    }

    res.json({
      message: 'Voting links sent',
      sent: sentCount,
      failed: failedCount,
      total: members.length
    });
  } catch (error) {
    console.error('Send voting links error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Send reminders to members who haven't voted
router.post('/:id/send-reminders', authenticateToken, async (req, res) => {
  try {
    const electionId = req.params.id;
    const frontendUrl = process.env.FRONTEND_URL || 'http://localhost:3000';

    const election = db.prepare('SELECT * FROM elections WHERE id = ?').get(electionId);
    if (!election) {
      return res.status(404).json({ error: 'Election not found' });
    }

    const members = db.prepare(`
      SELECT em.*, m.full_name, m.phone, m.whatsapp_number
      FROM election_members em
      JOIN members m ON em.member_id = m.id
      WHERE em.election_id = ? AND em.has_voted = 0
    `).all(electionId);

    let sentCount = 0;
    let failedCount = 0;

    for (const member of members) {
      const phone = member.whatsapp_number || member.phone;
      const votingUrl = `${frontendUrl}/vote/${member.voting_token}`;

      const result = await evolutionAPI.sendVotingReminder(
        phone,
        member.full_name,
        election.title,
        votingUrl,
        new Date(election.end_date).toLocaleDateString()
      );

      if (result.success) {
        sentCount++;
        db.prepare(`
          UPDATE election_members 
          SET reminder_count = reminder_count + 1, last_reminder_at = CURRENT_TIMESTAMP
          WHERE id = ?
        `).run(member.id);
      } else {
        failedCount++;
      }

      await new Promise(resolve => setTimeout(resolve, 500));
    }

    res.json({
      message: 'Reminders sent',
      sent: sentCount,
      failed: failedCount,
      total: members.length
    });
  } catch (error) {
    console.error('Send reminders error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Get election results
router.get('/:id/results', authenticateToken, (req, res) => {
  try {
    const election = db.prepare('SELECT * FROM elections WHERE id = ?').get(req.params.id);
    
    if (!election) {
      return res.status(404).json({ error: 'Election not found' });
    }

    const results = db.prepare(`
      SELECT c.id, c.name, c.description, c.photo_url,
        COUNT(v.id) as vote_count
      FROM candidates c
      LEFT JOIN votes v ON c.id = v.candidate_id
      WHERE c.election_id = ?
      GROUP BY c.id
      ORDER BY vote_count DESC
    `).all(req.params.id);

    const stats = db.prepare(`
      SELECT 
        COUNT(*) as total_members,
        SUM(CASE WHEN has_voted = 1 THEN 1 ELSE 0 END) as voted_count
      FROM election_members
      WHERE election_id = ?
    `).get(req.params.id);

    res.json({
      election,
      results,
      stats,
      turnout_percentage: stats.total_members > 0 
        ? ((stats.voted_count / stats.total_members) * 100).toFixed(2) 
        : 0
    });
  } catch (error) {
    console.error('Get results error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

module.exports = router;
