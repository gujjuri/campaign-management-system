const express = require('express');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const db = require('../database');
const { authenticateToken, requireAdmin } = require('../middleware/auth');

const router = express.Router();
const JWT_SECRET = process.env.JWT_SECRET || 'your-secret-key';

// Login
router.post('/login', (req, res) => {
  try {
    const { username, password } = req.body;

    if (!username || !password) {
      return res.status(400).json({ error: 'Username and password are required' });
    }

    const operator = db.prepare(`
      SELECT * FROM operators WHERE (username = ? OR email = ?) AND is_active = 1
    `).get(username, username);

    if (!operator) {
      return res.status(401).json({ error: 'Invalid credentials' });
    }

    const validPassword = bcrypt.compareSync(password, operator.password);
    if (!validPassword) {
      return res.status(401).json({ error: 'Invalid credentials' });
    }

    const token = jwt.sign(
      { id: operator.id, username: operator.username, role: operator.role },
      JWT_SECRET,
      { expiresIn: '24h' }
    );

    res.json({
      token,
      user: {
        id: operator.id,
        username: operator.username,
        email: operator.email,
        full_name: operator.full_name,
        role: operator.role
      }
    });
  } catch (error) {
    console.error('Login error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Get current user
router.get('/me', authenticateToken, (req, res) => {
  try {
    const operator = db.prepare(`
      SELECT id, username, email, full_name, role, created_at
      FROM operators WHERE id = ?
    `).get(req.user.id);

    if (!operator) {
      return res.status(404).json({ error: 'User not found' });
    }

    res.json(operator);
  } catch (error) {
    console.error('Get user error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Get all operators (admin only)
router.get('/operators', authenticateToken, requireAdmin, (req, res) => {
  try {
    const operators = db.prepare(`
      SELECT id, username, email, full_name, role, is_active, created_at
      FROM operators ORDER BY created_at DESC
    `).all();

    res.json(operators);
  } catch (error) {
    console.error('Get operators error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Create operator (admin only)
router.post('/operators', authenticateToken, requireAdmin, (req, res) => {
  try {
    const { username, email, password, full_name, role } = req.body;

    if (!username || !email || !password || !full_name) {
      return res.status(400).json({ error: 'All fields are required' });
    }

    const hashedPassword = bcrypt.hashSync(password, 10);

    const result = db.prepare(`
      INSERT INTO operators (username, email, password, full_name, role)
      VALUES (?, ?, ?, ?, ?)
    `).run(username, email, hashedPassword, full_name, role || 'operator');

    res.status(201).json({
      id: result.lastInsertRowid,
      username,
      email,
      full_name,
      role: role || 'operator'
    });
  } catch (error) {
    if (error.message.includes('UNIQUE constraint')) {
      return res.status(400).json({ error: 'Username or email already exists' });
    }
    console.error('Create operator error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Update operator (admin only)
router.put('/operators/:id', authenticateToken, requireAdmin, (req, res) => {
  try {
    const { id } = req.params;
    const { email, full_name, role, is_active, password } = req.body;

    let query = 'UPDATE operators SET email = ?, full_name = ?, role = ?, is_active = ?, updated_at = CURRENT_TIMESTAMP';
    let params = [email, full_name, role, is_active ? 1 : 0];

    if (password) {
      query += ', password = ?';
      params.push(bcrypt.hashSync(password, 10));
    }

    query += ' WHERE id = ?';
    params.push(id);

    db.prepare(query).run(...params);

    res.json({ message: 'Operator updated successfully' });
  } catch (error) {
    console.error('Update operator error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Change password
router.post('/change-password', authenticateToken, (req, res) => {
  try {
    const { currentPassword, newPassword } = req.body;

    const operator = db.prepare('SELECT password FROM operators WHERE id = ?').get(req.user.id);

    if (!bcrypt.compareSync(currentPassword, operator.password)) {
      return res.status(400).json({ error: 'Current password is incorrect' });
    }

    const hashedPassword = bcrypt.hashSync(newPassword, 10);
    db.prepare('UPDATE operators SET password = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?')
      .run(hashedPassword, req.user.id);

    res.json({ message: 'Password changed successfully' });
  } catch (error) {
    console.error('Change password error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

module.exports = router;
