const express = require('express');
const db = require('../database');
const { authenticateToken } = require('../middleware/auth');

const router = express.Router();

// Get dashboard statistics
router.get('/', authenticateToken, (req, res) => {
  try {
    // Member stats
    const memberStats = db.prepare(`
      SELECT 
        COUNT(*) as total_members,
        COUNT(CASE WHEN is_active = 1 THEN 1 END) as active_members
      FROM members
    `).get();

    // Campaign stats
    const campaignStats = db.prepare(`
      SELECT 
        COUNT(*) as total_campaigns,
        COUNT(CASE WHEN status = 'active' THEN 1 END) as active_campaigns,
        COUNT(CASE WHEN status = 'draft' THEN 1 END) as draft_campaigns,
        COUNT(CASE WHEN status = 'completed' THEN 1 END) as completed_campaigns,
        COUNT(CASE WHEN status = 'cancelled' THEN 1 END) as cancelled_campaigns
      FROM campaigns
    `).get();

    // Broadcast stats
    const broadcastStats = db.prepare(`
      SELECT 
        COUNT(*) as total_broadcasts,
        COALESCE(SUM(sent_count), 0) as total_messages_sent,
        COALESCE(SUM(failed_count), 0) as total_failed,
        COALESCE(SUM(CASE WHEN status = 'delivered' THEN 1 ELSE 0 END), 0) as delivered_count
      FROM broadcasts
    `).get();

    // Calculate delivery rate
    const deliveryRate = broadcastStats.total_messages_sent > 0 
      ? Math.round((broadcastStats.delivered_count / broadcastStats.total_messages_sent) * 100)
      : 0;
    broadcastStats.delivery_rate = deliveryRate;

    // Active campaigns with progress
    const activeCampaigns = db.prepare(`
      SELECT c.id, c.name, c.status,
        (SELECT COUNT(*) FROM campaign_members WHERE campaign_id = c.id) as total_members,
        (SELECT COUNT(DISTINCT member_id) FROM broadcast_recipients br
         JOIN broadcasts b ON br.broadcast_id = b.id
         WHERE b.campaign_id = c.id) as contacted_count
      FROM campaigns c
      WHERE c.status = 'active'
      ORDER BY c.created_at DESC
      LIMIT 5
    `).all();

    // Recent campaigns
    const recentCampaigns = db.prepare(`
      SELECT c.id, c.name, c.status, c.start_date, c.end_date,
        (SELECT COUNT(*) FROM campaign_members WHERE campaign_id = c.id) as member_count
      FROM campaigns c
      ORDER BY c.created_at DESC
      LIMIT 5
    `).all();

    // Recent broadcasts
    const recentBroadcasts = db.prepare(`
      SELECT id, title, message_type, status, sent_count, total_recipients, created_at
      FROM broadcasts
      ORDER BY created_at DESC
      LIMIT 5
    `).all();

    // Messages sent today
    const todayStats = db.prepare(`
      SELECT 
        COUNT(*) as messages_today
      FROM message_logs
      WHERE DATE(created_at) = DATE('now')
    `).get();

    res.json({
      members: memberStats,
      campaigns: campaignStats,
      broadcasts: broadcastStats,
      activeCampaigns,
      recentCampaigns,
      recentBroadcasts,
      todayStats
    });
  } catch (error) {
    console.error('Dashboard error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

module.exports = router;
