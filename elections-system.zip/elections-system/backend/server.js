require('dotenv').config();
const express = require('express');
const cors = require('cors');
const path = require('path');

// Initialize database
const db = require('./database');

// Import routes
const authRoutes = require('./routes/auth');
const campaignsRoutes = require('./routes/campaigns');
const membersRoutes = require('./routes/members');
const broadcastsRoutes = require('./routes/broadcasts');
const whatsappRoutes = require('./routes/whatsapp');
const dashboardRoutes = require('./routes/dashboard');

const app = express();
const PORT = process.env.PORT || 3001;

// Middleware
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Serve uploaded files
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));

// API Routes
app.use('/api/auth', authRoutes);
app.use('/api/campaigns', campaignsRoutes);
app.use('/api/members', membersRoutes);
app.use('/api/broadcasts', broadcastsRoutes);
app.use('/api/whatsapp', whatsappRoutes);
app.use('/api/dashboard', dashboardRoutes);

// Health check
app.get('/api/health', (req, res) => {
  res.json({ status: 'ok', timestamp: new Date().toISOString() });
});

// Serve React frontend in production
if (process.env.NODE_ENV === 'production') {
  app.use(express.static(path.join(__dirname, '../frontend/build')));
  
  app.get('*', (req, res) => {
    res.sendFile(path.join(__dirname, '../frontend/build', 'index.html'));
  });
}

// Error handling middleware
app.use((err, req, res, next) => {
  console.error(err.stack);
  res.status(500).json({ error: 'Something went wrong!' });
});

app.listen(PORT, () => {
  console.log(`
╔═══════════════════════════════════════════════════════════╗
║     Campaign Management System                             ║
║     Server running on http://localhost:${PORT}               ║
╠═══════════════════════════════════════════════════════════╣
║  Default Admin Login:                                      ║
║  Username: admin                                           ║
║  Password: admin123                                        ║
╚═══════════════════════════════════════════════════════════╝
  `);
});

module.exports = app;
════════════════╝
  `);
});

module.exports = app;
